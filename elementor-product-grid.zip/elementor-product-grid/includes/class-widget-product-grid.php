<?php
/**
 * Product Grid widget.
 *
 * @package Elementor_Product_Grid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;

/**
 * Product Grid widget.
 */
class EPG_Product_Grid_Widget extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'epg-product-grid';
	}

	/**
	 * Get widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Product Grid', 'elementor-product-grid' );
	}

	/**
	 * Get widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	/**
	 * Get widget categories.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'epg-products' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'product', 'grid', 'woocommerce', 'shop', 'epg', 'luxury' ];
	}

	/**
	 * Register controls.
	 */
	protected function register_controls() {
		$this->register_content_controls();
		$this->register_grid_style_controls();
		$this->register_card_style_controls();
		$this->register_brand_style_controls();
		$this->register_name_style_controls();
		$this->register_condition_style_controls();
		$this->register_price_style_controls();
		$this->register_badge_style_controls();
		$this->register_button_style_controls();
		$this->register_wishlist_style_controls();
	}

	/**
	 * Content controls.
	 */
	protected function register_content_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Products', 'elementor-product-grid' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'filter_type',
			[
				'label'   => esc_html__( 'Source', 'elementor-product-grid' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'all',
				'options' => [
					'all'      => esc_html__( 'All Products', 'elementor-product-grid' ),
					'specific' => esc_html__( 'Specific Categories', 'elementor-product-grid' ),
				],
			]
		);

		$this->add_control(
			'product_categories',
			[
				'label'       => esc_html__( 'Categories', 'elementor-product-grid' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'options'     => $this->get_term_options( 'product_cat' ),
				'condition'   => [ 'filter_type' => 'specific' ],
				'description' => esc_html__( 'Search and select one or more product categories (e.g. Handbags).', 'elementor-product-grid' ),
			]
		);

		$this->add_control(
			'product_brands',
			[
				'label'       => esc_html__( 'Brands', 'elementor-product-grid' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'options'     => $this->get_term_options( 'product_brand' ),
				'condition'   => [ 'filter_type' => 'specific' ],
				'description' => esc_html__( 'Search and select one or more brands (e.g. Hermès).', 'elementor-product-grid' ),
			]
		);

		$this->add_control(
			'products_count',
			[
				'label'   => esc_html__( 'Number of Products', 'elementor-product-grid' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 50,
				'step'    => 1,
				'default' => 8,
			]
		);

		$this->add_control(
			'brand_taxonomy',
			[
				'label'       => esc_html__( 'Brand Taxonomy Slug', 'elementor-product-grid' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'product_brand',
				'description' => esc_html__( 'The taxonomy that stores the brand (e.g. product_brand).', 'elementor-product-grid' ),
			]
		);

		$this->add_control(
			'condition_attr',
			[
				'label'       => esc_html__( 'Condition Attribute', 'elementor-product-grid' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'condition',
				'description' => esc_html__( 'The product attribute that stores condition (e.g. condition or pa_condition).', 'elementor-product-grid' ),
			]
		);

		$this->add_control(
			'year_attr',
			[
				'label'       => esc_html__( 'Year Attribute', 'elementor-product-grid' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'year',
				'description' => esc_html__( 'The product attribute that stores the year (e.g. year or pa_year).', 'elementor-product-grid' ),
			]
		);

		$this->add_control(
			'show_authenticated',
			[
				'label'        => esc_html__( 'Show Authenticated Badge', 'elementor-product-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-product-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-product-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_wishlist',
			[
				'label'        => esc_html__( 'Show Wishlist Button', 'elementor-product-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-product-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-product-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'new_in_days',
			[
				'label'       => esc_html__( 'New In (days)', 'elementor-product-grid' ),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 365,
				'step'        => 1,
				'default'     => 30,
				'description' => esc_html__( 'Products published within this many days get the "New In" badge. 0 disables it.', 'elementor-product-grid' ),
			]
		);

		$this->add_control(
			'limited_tag',
			[
				'label'       => esc_html__( 'Limited Tag Slug', 'elementor-product-grid' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'limited',
				'description' => esc_html__( 'Products with this product tag get the "Limited" badge.', 'elementor-product-grid' ),
			]
		);

		$this->add_control(
			'show_brand',
			[
				'label'        => esc_html__( 'Show Brand', 'elementor-product-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-product-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-product-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_name',
			[
				'label'        => esc_html__( 'Show Name', 'elementor-product-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-product-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-product-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_condition',
			[
				'label'        => esc_html__( 'Show Condition & Dots', 'elementor-product-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-product-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-product-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_price',
			[
				'label'        => esc_html__( 'Show Price', 'elementor-product-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-product-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-product-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Get term ID => name options for a taxonomy (used by the SELECT2 controls).
	 *
	 * @param string $taxonomy Taxonomy slug.
	 * @return array Term options.
	 */
	protected function get_term_options( $taxonomy ) {
		$taxonomy = trim( (string) $taxonomy );

		if ( '' === $taxonomy || ! taxonomy_exists( $taxonomy ) ) {
			return [];
		}

		$terms = get_terms(
			[
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
				'orderby'    => 'name',
				'order'      => 'ASC',
			]
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return [];
		}

		$options = [];
		foreach ( $terms as $term ) {
			$options[ $term->term_id ] = $term->name;
		}

		return $options;
	}

	/**
	 * Build the tax_query from the selected categories / brands.
	 *
	 * Categories and brands are combined with AND (a product must match both),
	 * while multiple terms within the same taxonomy are OR-ed together.
	 *
	 * @param array $settings Widget settings.
	 * @return array WP_Query tax_query.
	 */
	protected function build_tax_query( $settings ) {
		$filter_type = isset( $settings['filter_type'] ) ? $settings['filter_type'] : 'all';

		if ( 'specific' !== $filter_type ) {
			return [];
		}

		$tax_query = [];

		$categories = isset( $settings['product_categories'] ) ? $settings['product_categories'] : [];
		$categories = is_array( $categories ) ? array_filter( array_map( 'absint', $categories ) ) : [];

		if ( ! empty( $categories ) ) {
			$tax_query[] = [
				'taxonomy' => 'product_cat',
				'field'    => 'term_id',
				'terms'    => $categories,
				'operator' => 'IN',
			];
		}

		$brands = isset( $settings['product_brands'] ) ? $settings['product_brands'] : [];
		$brands = is_array( $brands ) ? array_filter( array_map( 'absint', $brands ) ) : [];

		if ( ! empty( $brands ) ) {
			$tax_query[] = [
				'taxonomy' => 'product_brand',
				'field'    => 'term_id',
				'terms'    => $brands,
				'operator' => 'IN',
			];
		}

		if ( count( $tax_query ) > 1 ) {
			$tax_query['relation'] = 'AND';
		}

		return $tax_query;
	}

	/**
	 * Grid style controls.
	 */
	protected function register_grid_style_controls() {
		$this->start_controls_section(
			'section_grid_style',
			[
				'label' => esc_html__( 'Grid', 'elementor-product-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'columns',
			[
				'label'          => esc_html__( 'Columns', 'elementor-product-grid' ),
				'type'           => Controls_Manager::NUMBER,
				'min'            => 1,
				'max'            => 12,
				'default'        => 4,
				'tablet_default' => 2,
				'mobile_default' => 1,
				'selectors'      => [
					'{{WRAPPER}} .epg-grid' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));',
				],
			]
		);

		$this->add_responsive_control(
			'column_gap',
			[
				'label'      => esc_html__( 'Column Gap', 'elementor-product-grid' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'size' => 24,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .epg-grid' => 'column-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'row_gap',
			[
				'label'      => esc_html__( 'Row Gap', 'elementor-product-grid' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'size' => 56,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .epg-grid' => 'row-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Card style controls.
	 */
	protected function register_card_style_controls() {
		$this->start_controls_section(
			'section_card_style',
			[
				'label' => esc_html__( 'Card', 'elementor-product-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'image_background',
			[
				'label'     => esc_html__( 'Image Background', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f5f0e8',
				'selectors' => [
					'{{WRAPPER}} .epg-image-wrapper' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'card_border',
				'label'     => esc_html__( 'Border', 'elementor-product-grid' ),
				'selector'  => '{{WRAPPER}} .epg-product',
				'default'   => [
					'border' => 'none',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Brand style controls.
	 */
	protected function register_brand_style_controls() {
		$this->start_controls_section(
			'section_brand_style',
			[
				'label' => esc_html__( 'Brand', 'elementor-product-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'brand_color',
			[
				'label'     => esc_html__( 'Color', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1a5c3a',
				'selectors' => [
					'{{WRAPPER}} .epg-brand' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'brand_typography',
				'label'    => esc_html__( 'Typography', 'elementor-product-grid' ),
				'selector' => '{{WRAPPER}} .epg-brand',
				'default'  => [
					'font_family'    => 'Arimo',
					'font_size'      => [ 'unit' => 'px', 'size' => 10 ],
					'font_weight'    => '500',
					'letter_spacing' => [ 'unit' => 'px', 'size' => 2 ],
					'text_transform' => 'uppercase',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Name style controls.
	 */
	protected function register_name_style_controls() {
		$this->start_controls_section(
			'section_name_style',
			[
				'label' => esc_html__( 'Name', 'elementor-product-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'name_color',
			[
				'label'     => esc_html__( 'Color', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .epg-name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'name_typography',
				'label'    => esc_html__( 'Typography', 'elementor-product-grid' ),
				'selector' => '{{WRAPPER}} .epg-name',
				'default'  => [
					'font_family'    => 'Cormorant Garamond',
					'font_size'      => [ 'unit' => 'px', 'size' => 17 ],
					'font_weight'    => '500',
					'letter_spacing' => [ 'unit' => 'px', 'size' => 0.34 ],
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Condition style controls.
	 */
	protected function register_condition_style_controls() {
		$this->start_controls_section(
			'section_condition_style',
			[
				'label' => esc_html__( 'Condition', 'elementor-product-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'condition_color',
			[
				'label'     => esc_html__( 'Text Color', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#999999',
				'selectors' => [
					'{{WRAPPER}} .epg-condition' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'condition_typography',
				'label'    => esc_html__( 'Typography', 'elementor-product-grid' ),
				'selector' => '{{WRAPPER}} .epg-condition',
				'default'  => [
					'font_family'    => 'Arimo',
					'font_size'      => [ 'unit' => 'px', 'size' => 11 ],
					'font_weight'    => '300',
					'letter_spacing' => [ 'unit' => 'px', 'size' => 0.44 ],
				],
			]
		);

		$this->add_control(
			'dot_on_color',
			[
				'label'     => esc_html__( 'Dot Active Color', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1a5c3a',
				'selectors' => [
					'{{WRAPPER}} .epg-dot--on' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'dot_off_color',
			[
				'label'     => esc_html__( 'Dot Inactive Color', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(0,0,0,0.12)',
				'selectors' => [
					'{{WRAPPER}} .epg-dot--off' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Price style controls.
	 */
	protected function register_price_style_controls() {
		$this->start_controls_section(
			'section_price_style',
			[
				'label' => esc_html__( 'Price', 'elementor-product-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'sale_heading',
			[
				'label' => esc_html__( 'Current Price', 'elementor-product-grid' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'sale_color',
			[
				'label'     => esc_html__( 'Color', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .epg-sale' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'sale_typography',
				'label'    => esc_html__( 'Typography', 'elementor-product-grid' ),
				'selector' => '{{WRAPPER}} .epg-sale',
				'default'  => [
					'font_family'    => 'Cormorant Garamond',
					'font_size'      => [ 'unit' => 'px', 'size' => 18 ],
					'font_weight'    => '500',
					'letter_spacing' => [ 'unit' => 'px', 'size' => 0.72 ],
				],
			]
		);

		$this->add_control(
			'regular_heading',
			[
				'label'     => esc_html__( 'Regular Price', 'elementor-product-grid' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'regular_color',
			[
				'label'     => esc_html__( 'Color', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#bbbbbb',
				'selectors' => [
					'{{WRAPPER}} .epg-regular' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'regular_typography',
				'label'    => esc_html__( 'Typography', 'elementor-product-grid' ),
				'selector' => '{{WRAPPER}} .epg-regular',
				'default'  => [
					'font_family'     => 'Cormorant Garamond',
					'font_size'       => [ 'unit' => 'px', 'size' => 14 ],
					'font_weight'     => '400',
					'letter_spacing'  => [ 'unit' => 'px', 'size' => 0.56 ],
					'text_decoration' => 'line-through',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Badge style controls.
	 */
	protected function register_badge_style_controls() {
		$this->start_controls_section(
			'section_badge_style',
			[
				'label' => esc_html__( 'Badges', 'elementor-product-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'auth_badge_background',
			[
				'label'     => esc_html__( 'Authenticated Background', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(255,255,255,0.92)',
				'selectors' => [
					'{{WRAPPER}} .epg-badge--auth' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'auth_badge_color',
			[
				'label'     => esc_html__( 'Authenticated Text', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1a5c3a',
				'selectors' => [
					'{{WRAPPER}} .epg-badge--auth' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'new_badge_background',
			[
				'label'     => esc_html__( 'New In Background', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .epg-badge--new' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'limited_badge_background',
			[
				'label'     => esc_html__( 'Limited Background', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1a5c3a',
				'selectors' => [
					'{{WRAPPER}} .epg-badge--limited' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'badge_typography',
				'label'    => esc_html__( 'Typography', 'elementor-product-grid' ),
				'selector' => '{{WRAPPER}} .epg-badge',
				'default'  => [
					'font_family'    => 'Arimo',
					'font_size'      => [ 'unit' => 'px', 'size' => 9 ],
					'font_weight'    => '500',
					'letter_spacing' => [ 'unit' => 'px', 'size' => 1.26 ],
					'text_transform' => 'uppercase',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Button style controls.
	 */
	protected function register_button_style_controls() {
		$this->start_controls_section(
			'section_button_style',
			[
				'label' => esc_html__( 'Action Bar', 'elementor-product-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'action_bar_background',
			[
				'label'     => esc_html__( 'Background', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(255,255,255,0.95)',
				'selectors' => [
					'{{WRAPPER}} .epg-actions' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'action_typography',
				'label'    => esc_html__( 'Typography', 'elementor-product-grid' ),
				'selector' => '{{WRAPPER}} .epg-action',
				'default'  => [
					'font_family'    => 'Arimo',
					'font_size'      => [ 'unit' => 'px', 'size' => 10 ],
					'font_weight'    => '500',
					'letter_spacing' => [ 'unit' => 'px', 'size' => 1.4 ],
					'text_transform' => 'uppercase',
				],
			]
		);

		$this->start_controls_tabs( 'action_style_tabs' );

		$this->start_controls_tab(
			'action_normal',
			[ 'label' => esc_html__( 'Normal', 'elementor-product-grid' ) ]
		);

		$this->add_control(
			'action_color',
			[
				'label'     => esc_html__( 'Text Color', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .epg-action' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'action_hover',
			[ 'label' => esc_html__( 'Hover', 'elementor-product-grid' ) ]
		);

		$this->add_control(
			'action_hover_color',
			[
				'label'     => esc_html__( 'Hover Text Color', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1a5c3a',
				'selectors' => [
					'{{WRAPPER}} .epg-action:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Wishlist (heart) button style controls.
	 */
	protected function register_wishlist_style_controls() {
		$this->start_controls_section(
			'section_wishlist_style',
			[
				'label' => esc_html__( 'Wishlist Button', 'elementor-product-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'wishlist_icon',
			[
				'label'   => esc_html__( 'Icon (Normal)', 'elementor-product-grid' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value'   => 'far fa-heart',
					'library' => 'fa-regular',
				],
			]
		);

		$this->add_control(
			'wishlist_icon_active',
			[
				'label'   => esc_html__( 'Icon (Active / Added)', 'elementor-product-grid' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value'   => 'fas fa-heart',
					'library' => 'fa-solid',
				],
			]
		);

		$this->add_control(
			'wishlist_icon_size',
			[
				'label'      => esc_html__( 'Icon Size', 'elementor-product-grid' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 12,
						'max' => 40,
					],
				],
				'default'    => [
					'size' => 18,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .epg-wishlist-btn i'   => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .epg-wishlist-btn svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'wishlist_style_tabs' );

		$this->start_controls_tab(
			'wishlist_normal',
			[ 'label' => esc_html__( 'Normal', 'elementor-product-grid' ) ]
		);

		$this->add_control(
			'wishlist_color',
			[
				'label'     => esc_html__( 'Color', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .epg-wishlist-btn'     => 'color: {{VALUE}};',
					'{{WRAPPER}} .epg-wishlist-btn svg' => 'fill: {{VALUE}}; stroke: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'wishlist_hover',
			[ 'label' => esc_html__( 'Hover', 'elementor-product-grid' ) ]
		);

		$this->add_control(
			'wishlist_hover_color',
			[
				'label'     => esc_html__( 'Hover Color', 'elementor-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .epg-wishlist-btn:hover'     => 'color: {{VALUE}};',
					'{{WRAPPER}} .epg-wishlist-btn:hover svg' => 'fill: {{VALUE}}; stroke: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Render the widget.
	 */
	protected function render() {
		if ( ! function_exists( 'wc_get_products' ) ) {
			return;
		}

		$settings = $this->get_settings_for_display();

		$limit = absint( $settings['products_count'] );
		if ( $limit < 1 ) {
			$limit = 8;
		}

		$args = [
			'status'  => 'publish',
			'limit'   => $limit,
			'orderby' => 'date',
			'order'   => 'DESC',
		];

		$tax_query = $this->build_tax_query( $settings );
		if ( ! empty( $tax_query ) ) {
			$args['tax_query'] = $tax_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
		}

		$products = wc_get_products( $args );

		if ( empty( $products ) ) {
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				echo '<p class="epg-empty">' . esc_html__( 'No products found.', 'elementor-product-grid' ) . '</p>';
			}
			return;
		}

		echo '<div class="epg-grid">';

		foreach ( $products as $product ) {
			$this->render_product( $product, $settings );
		}

		echo '</div>';
	}

	/**
	 * Render a single product card.
	 *
	 * @param \WC_Product $product  Product object.
	 * @param array       $settings Widget settings.
	 */
	protected function render_product( $product, $settings ) {
		$id        = $product->get_id();
		$name      = $product->get_name();
		$permalink = get_permalink( $id );

		$image_id = $product->get_image_id();
		$gallery  = $product->get_gallery_image_ids();
		$hover_id = ! empty( $gallery[0] ) ? $gallery[0] : 0;

		$wrapper_class = 'epg-image-wrapper' . ( $hover_id ? ' has-hover' : '' );

		echo '<div class="epg-product">';
		echo '<div class="' . esc_attr( $wrapper_class ) . '">';

		echo '<a class="epg-link" href="' . esc_url( $permalink ) . '">';

		if ( $image_id ) {
			$main_src = wp_get_attachment_image_url( $image_id, 'large' );
			if ( $main_src ) {
				echo '<img class="epg-img epg-img--primary" src="' . esc_url( $main_src ) . '" alt="' . esc_attr( $name ) . '" loading="lazy">';
			}
		}

		if ( $hover_id ) {
			$hover_src = wp_get_attachment_image_url( $hover_id, 'large' );
			if ( $hover_src ) {
				echo '<img class="epg-img epg-img--hover" src="' . esc_url( $hover_src ) . '" alt="' . esc_attr( $name ) . '" loading="lazy">';
			}
		}

		echo '</a>'; // .epg-link

		if ( 'yes' === $settings['show_authenticated'] ) {
			echo '<div class="epg-badge epg-badge--auth">';
			echo $this->svg_auth(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '<span>' . esc_html__( 'Authenticated', 'elementor-product-grid' ) . '</span>';
			echo '</div>';
		}

		$badge        = $this->get_new_badge( $product, $settings );
		$has_wishlist = ( 'yes' === $settings['show_wishlist'] && shortcode_exists( 'woosw' ) );

		if ( '' !== $badge || $has_wishlist ) {
			echo '<div class="epg-badges-right">';

			if ( '' !== $badge ) {
				$badge_class = 'limited' === $badge ? 'epg-badge--limited' : 'epg-badge--new';
				$badge_text  = 'limited' === $badge ? __( 'Limited', 'elementor-product-grid' ) : __( 'New In', 'elementor-product-grid' );
				echo '<div class="epg-badge ' . esc_attr( $badge_class ) . '">';
				echo '<span>' . esc_html( $badge_text ) . '</span>';
				echo '</div>';
			}

			if ( $has_wishlist ) {
				/*
				 * The `woosw-btn-has-icon` class is REQUIRED — do not remove it.
				 *
				 * WPC Smart Wishlist's frontend.js runs woosw_refresh_buttons() on
				 * every page load and executes:
				 *     $( '.woosw-btn:not(.woosw-btn-has-icon)' ).text( woosw_vars.button_text )
				 * jQuery .text() replaces *all* child nodes, so it deleted our two heart
				 * spans and left the bare string "Add to wishlist" (and "Browse wishlist"
				 * once the product was added).
				 *
				 * Declaring the button as "has icon" sends woosw down its icon branch,
				 * which only touches `.woosw-btn-icon` / `.woosw-btn-text` children. We
				 * render neither, so woosw writes no text and never touches our markup.
				 * The `woosw-added` state class is applied outside that branch, so the
				 * empty-heart/filled-heart swap keeps working.
				 */
				echo '<button class="woosw-btn woosw-btn-has-icon woosw-btn-' . esc_attr( $id ) . ' epg-wishlist-btn" data-id="' . esc_attr( $id ) . '" aria-label="' . esc_attr__( 'Wishlist', 'elementor-product-grid' ) . '">';
				echo '<span class="epg-wishlist-icon epg-wishlist-icon--off">';
				\Elementor\Icons_Manager::render_icon( $settings['wishlist_icon'], [ 'aria-hidden' => 'true' ] );
				echo '</span>';
				echo '<span class="epg-wishlist-icon epg-wishlist-icon--on">';
				\Elementor\Icons_Manager::render_icon( $settings['wishlist_icon_active'], [ 'aria-hidden' => 'true' ] );
				echo '</span>';
				echo '</button>';
			}

			echo '</div>';
		}

		echo '<div class="epg-actions">';
		echo '<a class="epg-action epg-action--bag epg-add-to-bag add_to_cart_button ajax_add_to_cart" href="' . esc_url( $product->add_to_cart_url() ) . '" data-product_id="' . esc_attr( $id ) . '" data-quantity="1" rel="nofollow">';
		echo $this->svg_bag(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<span class="epg-action-text">' . esc_html__( 'Add to Bag', 'elementor-product-grid' ) . '</span>';
		echo '</a>';
		echo '<span class="epg-sep">|</span>';
		echo '<a class="epg-action epg-action--view" href="' . esc_url( $permalink ) . '">';
		echo $this->svg_view(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<span>' . esc_html__( 'View Details', 'elementor-product-grid' ) . '</span>';
		echo '</a>';
		echo '</div>'; // .epg-actions

		echo '</div>'; // .epg-image-wrapper

		echo '<div class="epg-content">';

		if ( 'yes' === $settings['show_brand'] ) {
			$brand = $this->get_brand( $product, $settings['brand_taxonomy'] );
			if ( '' !== $brand ) {
				echo '<div class="epg-brand">' . esc_html( $brand ) . '</div>';
			}
		}

		if ( 'yes' === $settings['show_name'] ) {
			echo '<h3 class="epg-name">' . esc_html( $name ) . '</h3>';
		}

		if ( 'yes' === $settings['show_condition'] ) {
			$condition_text = $this->get_condition_text( $product, $settings );
			$dots           = $this->get_condition_dots( $this->get_attribute( $product, $settings['condition_attr'] ) );

			if ( '' !== $condition_text || $dots > 0 ) {
				if ( '' !== $condition_text ) {
					echo '<div class="epg-condition">' . esc_html( $condition_text ) . '</div>';
				}
				echo $this->render_dots( $dots ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}

		if ( 'yes' === $settings['show_price'] ) {
			echo '<div class="epg-price">';
			$this->render_price( $product );
			echo '</div>';
		}

		echo '</div>'; // .epg-content

		echo '</div>'; // .epg-product
	}

	/**
	 * Get the brand term name.
	 *
	 * @param \WC_Product $product Product object.
	 * @param string      $tax     Taxonomy slug.
	 * @return string Brand name, or empty string.
	 */
	protected function get_brand( $product, $tax ) {
		$tax = trim( (string) $tax );
		if ( '' === $tax ) {
			return '';
		}

		$terms = get_the_terms( $product->get_id(), $tax );
		if ( $terms && ! is_wp_error( $terms ) && ! empty( $terms[0] ) ) {
			return $terms[0]->name;
		}

		return '';
	}

	/**
	 * Get a product attribute value.
	 *
	 * @param \WC_Product $product Product object.
	 * @param string      $attr    Attribute name.
	 * @return string Attribute value, or empty string.
	 */
	protected function get_attribute( $product, $attr ) {
		$attr = trim( (string) $attr );
		if ( '' === $attr ) {
			return '';
		}

		$value = $product->get_attribute( $attr );

		return is_string( $value ) ? trim( $value ) : '';
	}

	/**
	 * Build the condition text ("Very Good · 2021").
	 *
	 * @param \WC_Product $product  Product object.
	 * @param array       $settings Widget settings.
	 * @return string Condition text, or empty string.
	 */
	protected function get_condition_text( $product, $settings ) {
		$condition = $this->get_attribute( $product, $settings['condition_attr'] );
		$year      = $this->get_attribute( $product, $settings['year_attr'] );

		if ( '' !== $condition && '' !== $year ) {
			return $condition . ' · ' . $year;
		}

		if ( '' !== $condition ) {
			return $condition;
		}

		if ( '' !== $year ) {
			return $year;
		}

		return '';
	}

	/**
	 * Map a condition label to a number of active dots (0-10).
	 *
	 * @param string $condition Condition label.
	 * @return int Active dot count.
	 */
	protected function get_condition_dots( $condition ) {
		$map = apply_filters(
			'epg_condition_dots_map',
			[
				'new'        => 10,
				'unused'     => 10,
				'pristine'   => 10,
				'never worn' => 10,
				'excellent'  => 9,
				'like new'   => 9,
				'like-new'   => 9,
				'very good'  => 8,
				'very-good'  => 8,
				'good'       => 7,
				'fair'       => 5,
				'poor'       => 3,
			]
		);

		$key = strtolower( trim( (string) $condition ) );

		return isset( $map[ $key ] ) ? (int) $map[ $key ] : 8;
	}

	/**
	 * Render the 10 condition dots.
	 *
	 * @param int $active Number of active dots.
	 * @return string Dots markup.
	 */
	protected function render_dots( $active ) {
		$active = max( 0, min( 10, (int) $active ) );
		$html   = '<div class="epg-dots">';

		for ( $i = 0; $i < 10; $i++ ) {
			$class = $i < $active ? 'epg-dot epg-dot--on' : 'epg-dot epg-dot--off';
			$html .= '<span class="' . $class . '"></span>';
		}

		$html .= '</div>';

		return $html;
	}

	/**
	 * Determine the "New In" / "Limited" badge for a product.
	 *
	 * @param \WC_Product $product  Product object.
	 * @param array       $settings Widget settings.
	 * @return string 'limited', 'new', or empty string.
	 */
	protected function get_new_badge( $product, $settings ) {
		$limited_tag = trim( (string) $settings['limited_tag'] );
		if ( '' !== $limited_tag && has_term( $limited_tag, 'product_tag', $product->get_id() ) ) {
			return 'limited';
		}

		$days = absint( $settings['new_in_days'] );
		if ( $days < 1 ) {
			return '';
		}

		$created = $product->get_date_created();
		if ( ! $created ) {
			return '';
		}

		$created_ts = $created->getTimestamp();

		return ( time() - $created_ts ) < ( $days * DAY_IN_SECONDS ) ? 'new' : '';
	}

	/**
	 * Render the product price (current + regular).
	 *
	 * @param \WC_Product $product Product object.
	 */
	protected function render_price( $product ) {
		$regular = $product->get_regular_price();
		$sale    = $product->get_sale_price();

		if ( '' !== $sale && '' !== $regular && (float) $sale < (float) $regular ) {
			echo '<span class="epg-sale">' . wc_price( $sale ) . '</span>';
			echo '<span class="epg-regular">' . wc_price( $regular ) . '</span>';
			return;
		}

		$price = $product->get_price();
		if ( '' === $price ) {
			return;
		}

		echo '<span class="epg-sale">' . wc_price( $price ) . '</span>';
	}

	/**
	 * Authenticated (shield) icon SVG.
	 *
	 * @return string Inline SVG.
	 */
	protected function svg_auth() {
		return <<<'SVG'
<svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.33333 5.41667C8.33333 7.5 6.875 8.54167 5.14167 9.14583C5.0509 9.17659 4.95231 9.17512 4.8625 9.14167C3.125 8.54167 1.66667 7.5 1.66667 5.41667V2.5C1.66667 2.38949 1.71057 2.28351 1.78871 2.20537C1.86685 2.12723 1.97283 2.08333 2.08333 2.08333C2.91667 2.08333 3.95833 1.58333 4.68333 0.95C4.77161 0.874583 4.8839 0.833146 5 0.833146C5.1161 0.833146 5.22839 0.874583 5.31667 0.95C6.04583 1.5875 7.08333 2.08333 7.91667 2.08333C8.02717 2.08333 8.13315 2.12723 8.21129 2.20537C8.28943 2.28351 8.33333 2.38949 8.33333 2.5V5.41667Z" stroke="#1A5C3A" stroke-width="0.833333" stroke-linecap="round" stroke-linejoin="round"/><path d="M3.75 5L4.58333 5.83333L6.25 4.16667" stroke="#1A5C3A" stroke-width="0.833333" stroke-linecap="round" stroke-linejoin="round"/></svg>
SVG;
	}

	/**
	 * Shopping bag icon SVG.
	 *
	 * @return string Inline SVG.
	 */
	protected function svg_bag() {
		return <<<'SVG'
<svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.25 1.08333L1.625 3.25V10.8333C1.625 11.1207 1.73914 11.3962 1.9423 11.5994C2.14547 11.8025 2.42102 11.9167 2.70833 11.9167H10.2917C10.579 11.9167 10.8545 11.8025 11.0577 11.5994C11.2609 11.3962 11.375 11.1207 11.375 10.8333V3.25L9.75 1.08333H3.25Z" stroke="black" stroke-width="0.8125" stroke-linecap="round" stroke-linejoin="round"/><path d="M1.625 3.25H11.375" stroke="black" stroke-width="0.8125" stroke-linecap="round" stroke-linejoin="round"/><path d="M8.66667 5.41667C8.66667 5.9913 8.43839 6.5424 8.03206 6.94873C7.62574 7.35506 7.07464 7.58333 6.5 7.58333C5.92536 7.58333 5.37426 7.35506 4.96793 6.94873C4.56161 6.5424 4.33333 5.9913 4.33333 5.41667" stroke="black" stroke-width="0.8125" stroke-linecap="round" stroke-linejoin="round"/></svg>
SVG;
	}

	/**
	 * Eye (view details) icon SVG.
	 *
	 * @return string Inline SVG.
	 */
	protected function svg_view() {
		return <<<'SVG'
<svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.11692 6.3115C1.07177 6.43311 1.07177 6.56689 1.11692 6.6885C1.55659 7.75458 2.3029 8.6661 3.26125 9.30751C4.2196 9.94892 5.34682 10.2913 6.5 10.2913C7.65318 10.2913 8.7804 9.94892 9.73875 9.30751C10.6971 8.6661 11.4434 7.75458 11.8831 6.6885C11.9282 6.56689 11.9282 6.43311 11.8831 6.3115C11.4434 5.24542 10.6971 4.3339 9.73875 3.69249C8.7804 3.05108 7.65318 2.70867 6.5 2.70867C5.34682 2.70867 4.2196 3.05108 3.26125 3.69249C2.3029 4.3339 1.55659 5.24542 1.11692 6.3115Z" stroke="black" stroke-width="0.8125" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.5 8.125C7.39746 8.125 8.125 7.39746 8.125 6.5C8.125 5.60254 7.39746 4.875 6.5 4.875C5.60254 4.875 4.875 5.60254 4.875 6.5C4.875 7.39746 5.60254 8.125 6.5 8.125Z" stroke="black" stroke-width="0.8125" stroke-linecap="round" stroke-linejoin="round"/></svg>
SVG;
	}

	/**
	 * Empty heart icon SVG.
	 *
	 * @return string Inline SVG.
	 */
	protected function svg_heart() {
		return '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>';
	}

	/**
	 * Filled heart icon SVG.
	 *
	 * @return string Inline SVG.
	 */
	protected function svg_heart_filled() {
		return '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>';
	}
}
