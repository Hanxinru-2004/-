<?php
/**
 * Plugin Name:       Elementor Brand Grid
 * Plugin URI:        https://example.com/elementor-brand-grid
 * Description:       A WooCommerce brand-filtered product grid widget for Elementor. Shows a horizontal brand filter (ALL + every WooCommerce product brand), a sort dropdown, a live product count, hover image swap, badges and AJAX add-to-cart. Designed around a pre-owned luxury aesthetic (Cormorant Garamond + Jost + deep-green accent).
 * Version:           1.2.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       elementor-brand-grid
 * Domain Path:       /languages
 *
 * @package Elementor_Brand_Grid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'EBG_VERSION', '1.2.0' );
define( 'EBG_PATH', plugin_dir_path( __FILE__ ) );
define( 'EBG_URL', plugin_dir_url( __FILE__ ) );

/**
 * Register the widget.
 *
 * The widget class is required lazily so this file can be loaded even when
 * Elementor is not active (the action never fires in that case).
 *
 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
 */
function ebg_register_widget( $widgets_manager ) {
	require_once EBG_PATH . 'includes/class-widget-brand-grid.php';
	$widgets_manager->register( new EBG_Brand_Grid_Widget() );
}
add_action( 'elementor/widgets/register', 'ebg_register_widget' );

/**
 * Register a custom Elementor category for this widget.
 *
 * @param \Elementor\Elements_Manager $elements_manager Elementor elements manager.
 */
function ebg_register_category( $elements_manager ) {
	$elements_manager->add_category(
		'ebg-brand',
		[
			'title' => esc_html__( 'Brand', 'elementor-brand-grid' ),
			'icon'  => 'fa fa-plug',
		]
	);
}
add_action( 'elementor/elements/categories_registered', 'ebg_register_category' );

/**
 * Enqueue the frontend stylesheet.
 */
function ebg_enqueue_styles() {
	wp_enqueue_style(
		'ebg-brand-grid',
		EBG_URL . 'assets/css/brand-grid.css',
		[],
		EBG_VERSION
	);
}
add_action( 'elementor/frontend/after_enqueue_styles', 'ebg_enqueue_styles' );

/**
 * Enqueue the Google Fonts used by the design spec (Cormorant Garamond + Jost).
 * Hooked to both frontend and the Elementor preview so the editor shows the
 * correct typefaces.
 */
function ebg_enqueue_fonts() {
	wp_enqueue_style(
		'ebg-google-fonts',
		'https://fonts.googleapis.com/css2?family=Jost:wght@300;400;500&family=Cormorant+Garamond:wght@400;500&display=swap',
		[],
		null
	);
}
add_action( 'wp_enqueue_scripts', 'ebg_enqueue_fonts' );
add_action( 'elementor/preview/enqueue_styles', 'ebg_enqueue_fonts' );

/**
 * Enqueue WooCommerce's AJAX add-to-cart script (reused, not duplicated) plus
 * this widget's own enhancement script, and localize the AJAX endpoint.
 */
function ebg_enqueue_scripts() {
	if ( function_exists( 'WC' ) ) {
		wp_enqueue_script( 'wc-add-to-cart' );
	}

	wp_enqueue_script(
		'ebg-brand-grid',
		EBG_URL . 'assets/js/brand-grid.js',
		[ 'jquery' ],
		EBG_VERSION,
		true
	);

	wp_localize_script(
		'ebg-brand-grid',
		'ebgBrandGrid',
		[
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'ebg_brand_grid' ),
			'i18n'    => [
				'error' => esc_html__( 'Something went wrong. Please try again.', 'elementor-brand-grid' ),
			],
		]
	);
}
add_action( 'elementor/frontend/after_enqueue_scripts', 'ebg_enqueue_scripts' );

/**
 * AJAX handler: filter / sort the product grid without a page refresh.
 *
 * Reuses the widget's own render logic so the frontend and AJAX markup always
 * stay in sync.
 */
function ebg_ajax_filter_products() {
	check_ajax_referer( 'ebg_brand_grid', 'nonce' );

	if ( ! function_exists( 'wc_get_product' ) ) {
		wp_send_json_error();
	}

	$brand    = isset( $_POST['brand'] ) ? sanitize_text_field( wp_unslash( $_POST['brand'] ) ) : 'all';
	$orderby  = isset( $_POST['orderby'] ) ? sanitize_key( wp_unslash( $_POST['orderby'] ) ) : 'default';
	$paged    = isset( $_POST['paged'] ) ? absint( $_POST['paged'] ) : 1;
	$raw      = isset( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

	// Settings may arrive as a JSON string (from the data-settings attribute).
	$settings = is_array( $raw ) ? $raw : json_decode( (string) $raw, true );
	if ( ! is_array( $settings ) ) {
		$settings = [];
	}

	require_once EBG_PATH . 'includes/class-widget-brand-grid.php';

	$widget = new EBG_Brand_Grid_Widget();
	$result = $widget->render_products( $settings, $brand, $orderby, $paged );

	wp_send_json_success(
		[
			'html'        => $result['html'],
			'count'       => $result['count'],
			'count_label' => $widget->render_count_label( $result['count'] ),
			'pagination'  => $widget->render_pagination( $result['page'], $result['pages'] ),
		]
	);
}
add_action( 'wp_ajax_ebg_filter_products', 'ebg_ajax_filter_products' );
add_action( 'wp_ajax_nopriv_ebg_filter_products', 'ebg_ajax_filter_products' );

/**
 * Invalidate the cached product-brand list whenever any taxonomy term changes.
 *
 * The brand list is cached per-taxonomy (the slug is part of the transient key),
 * so deleting the matching transient on any term change keeps the filter fresh
 * without needing to know which taxonomy the widget is configured to use.
 *
 * @param int    $term_id  Term ID.
 * @param int    $tt_id    Term taxonomy ID.
 * @param string $taxonomy Taxonomy slug.
 */
function ebg_flush_brand_cache( $term_id, $tt_id, $taxonomy ) {
	delete_transient( 'ebg_brands_' . $taxonomy );
}
add_action( 'created_term', 'ebg_flush_brand_cache', 10, 3 );
add_action( 'edited_term', 'ebg_flush_brand_cache', 10, 3 );
add_action( 'delete_term', 'ebg_flush_brand_cache', 10, 3 );

/**
 * Invalidate a brand list when products are assigned to (or re-assigned to) a
 * taxonomy. The term create/edit/delete hooks above don't fire for a plain
 * product ↔ term assignment, so this keeps the hide_empty brand filter fresh.
 *
 * @param int    $object_id Object ID.
 * @param array  $terms     Term names.
 * @param array  $tt_ids    Term taxonomy IDs.
 * @param string $taxonomy  Taxonomy slug.
 */
function ebg_flush_on_term_assignment( $object_id, $terms, $tt_ids, $taxonomy ) {
	delete_transient( 'ebg_brands_' . $taxonomy );
}
add_action( 'set_object_terms', 'ebg_flush_on_term_assignment', 10, 4 );

/**
 * Show an admin notice when required plugins are missing.
 */
function ebg_admin_notice() {
	$missing = [];

	if ( ! did_action( 'elementor/loaded' ) ) {
		$missing[] = 'Elementor';
	}

	if ( ! class_exists( 'WooCommerce' ) ) {
		$missing[] = 'WooCommerce';
	}

	if ( empty( $missing ) ) {
		return;
	}

	printf(
		'<div class="notice notice-warning"><p>%s</p></div>',
		esc_html(
			sprintf(
				/* translators: %s: comma-separated list of missing plugins. */
				__( 'Elementor Brand Grid requires %s to be installed and activated.', 'elementor-brand-grid' ),
				implode( ' and ', $missing )
			)
		)
	);
}
add_action( 'admin_notices', 'ebg_admin_notice' );
