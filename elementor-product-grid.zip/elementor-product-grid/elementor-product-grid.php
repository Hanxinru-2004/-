<?php
/**
 * Plugin Name:       Elementor Product Grid
 * Plugin URI:        https://example.com/elementor-product-grid
 * Description:       A WooCommerce product grid widget for Elementor with hover image swap, slide-up actions, and AJAX add-to-cart. Designed around a pre-owned luxury aesthetic (Cormorant Garamond + Arimo + deep-green accent).
 * Version:           1.2.1
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       elementor-product-grid
 * Domain Path:       /languages
 *
 * @package Elementor_Product_Grid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'EPG_VERSION', '1.2.1' );
define( 'EPG_PATH', plugin_dir_path( __FILE__ ) );
define( 'EPG_URL', plugin_dir_url( __FILE__ ) );

/**
 * Register the widget.
 *
 * The widget class is required lazily so this file can be loaded even when
 * Elementor is not active (the action never fires in that case).
 *
 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
 */
function epg_register_widget( $widgets_manager ) {
	require_once EPG_PATH . 'includes/class-widget-product-grid.php';
	$widgets_manager->register( new EPG_Product_Grid_Widget() );
}
add_action( 'elementor/widgets/register', 'epg_register_widget' );

/**
 * Register a custom Elementor category for this widget.
 *
 * @param \Elementor\Elements_Manager $elements_manager Elementor elements manager.
 */
function epg_register_category( $elements_manager ) {
	$elements_manager->add_category(
		'epg-products',
		[
			'title' => esc_html__( 'Products', 'elementor-product-grid' ),
			'icon'  => 'fa fa-plug',
		]
	);
}
add_action( 'elementor/elements/categories_registered', 'epg_register_category' );

/**
 * Enqueue the frontend stylesheet.
 */
function epg_enqueue_styles() {
	wp_enqueue_style(
		'epg-product-grid',
		EPG_URL . 'assets/css/product-grid.css',
		[],
		EPG_VERSION
	);
}
add_action( 'elementor/frontend/after_enqueue_styles', 'epg_enqueue_styles' );

/**
 * Enqueue the Google Fonts used by the design spec (Cormorant Garamond + Arimo).
 * Hooked to both frontend and the Elementor preview so the editor shows the
 * correct typefaces.
 */
function epg_enqueue_fonts() {
	wp_enqueue_style(
		'epg-google-fonts',
		'https://fonts.googleapis.com/css2?family=Arimo:wght@300;400;500&family=Cormorant+Garamond:wght@400;500&display=swap',
		[],
		null
	);
}
add_action( 'wp_enqueue_scripts', 'epg_enqueue_fonts' );
add_action( 'elementor/preview/enqueue_styles', 'epg_enqueue_fonts' );

/**
 * Enqueue WooCommerce's AJAX add-to-cart script (reused, not duplicated) plus
 * this widget's own enhancement script.
 */
function epg_enqueue_scripts() {
	if ( function_exists( 'WC' ) ) {
		wp_enqueue_script( 'wc-add-to-cart' );
	}

	wp_enqueue_script(
		'epg-product-grid',
		EPG_URL . 'assets/js/product-grid.js',
		[ 'jquery' ],
		EPG_VERSION,
		true
	);
}
add_action( 'elementor/frontend/after_enqueue_scripts', 'epg_enqueue_scripts' );

/**
 * Show an admin notice when required plugins are missing.
 */
function epg_admin_notice() {
	$missing = [];

	if ( ! did_action( 'elementor/loaded' ) ) {
		$missing[] = 'Elementor';
	}

	if ( ! class_exists( 'WooCommerce' ) ) {
		$missing[] = 'WooCommerce';
	}

	if ( empty( $missing ) ) {
		return;
	}

	printf(
		'<div class="notice notice-warning"><p>%s</p></div>',
		esc_html(
			sprintf(
				/* translators: %s: comma-separated list of missing plugins. */
				__( 'Elementor Product Grid requires %s to be installed and activated.', 'elementor-product-grid' ),
				implode( ' and ', $missing )
			)
		)
	);
}
add_action( 'admin_notices', 'epg_admin_notice' );
