# Elementor Brand Grid

一个 WooCommerce **品牌筛选**产品网格 Elementor 小部件，用于还原 Figma 设计稿的布局与样式：

- 左上角 **品牌筛选**（ALL / 各品牌，横向排列，激活态黑底白字）
- 右上角 **排序下拉**（Default Order / Random / Featured / Price: Low to High / Price: High to Low / Newest，默认 Default Order）+ **产品数量**（如 `8 pieces`）
- 产品卡片 **悬停换图**（主图 ↔ 图库第一张图，移开恢复主图）、徽章（Authenticated / New In / Limited）、滑出操作栏（Add to Bag / View Details）
- 品牌筛选、排序均通过 **AJAX** 实现，无需刷新页面
- 产品数据来自 **WooCommerce**（简单产品 / 可变产品）

## 依赖

- WordPress 6.0+
- PHP 7.4+
- Elementor
- WooCommerce

## 安装

1. 把整个 `elementor-brand-grid` 文件夹放到 WordPress 的 `wp-content/plugins/` 目录下：
   ```
   wp-content/plugins/elementor-brand-grid/elementor-brand-grid.php
   ```
   也可以把文件夹打成 `.zip`，在后台「插件 → 安装插件 → 上传插件」上传。
2. 后台启用 **Elementor Brand Grid**。
3. 确认 **Elementor** 与 **WooCommerce** 已安装并启用。

## 使用

1. 新建/编辑页面，点击 **用 Elementor 编辑**。
2. 在左侧「添加元素」面板中搜索 **Brand Grid**（分类为 **Brand**）。
3. 拖入页面，在左侧面板配置：
   - **Products**：每行几个（Products per Row，3/4/6）、每列几个（Products per Column / Rows，默认 2，**每页产品数 = 每行 × 每列**）、是否显示品牌筛选 / 排序下拉 / 产品数量 / Add to Bag / View Details，以及品牌分类、成色/年份属性、限量标签等字段映射。
   - 品牌筛选栏默认选中 **All**，展示全部产品；点击某个品牌 AJAX 筛选对应品牌的产品。
   - 产品列表下方自动显示分页（1 2 3 …），点击分页 / 切换品牌 / 排序均 AJAX 更新，无需刷新。
   - **Filter & Sort / Grid / Card / Brand Label / Name / Condition / Price / Badges / Action Bar**：样式控制（颜色、字体等）。
4. 前台页面即可看到完整效果，点击品牌或切换排序会自动 AJAX 更新。

## 字段映射（默认值，均可在 Elementor 面板修改）

| 项 | 默认字段 |
|---|---|
| 品牌（筛选 + 卡片品牌标签） | `product_brand` 分类法 |
| 成色 | `condition` 产品属性 |
| 年份 | `year` 产品属性 |
| 限量标签 | `limited` 产品标签 |

> 默认排序为 **Default Order**（按产品上传时间先后排序）。**Featured** 表示「仅显示标记为 WooCommerce 精选（Featured）的商品，按最新排序」。

> 可变产品（Variable）的「Add to Bag」按钮会链接到产品详情页选择规格；简单产品（Simple）走 AJAX 加购。

## 深链跳转（URL 参数直达某品牌）

**v1.2.0** 起，页面首次加载时会读取一个 URL 查询参数（默认 `ebg_brand`），
自动把品牌筛选切到对应品牌。这样首页的品牌栏 / 品牌 Logo 只要链接到
`https://你的域名/?ebg_brand=chanel`（带品牌分类法 slug），点一下就能直达
该品牌的产品网格，无需先落到 ALL 再手动点。

- 参数名可在 Elementor 面板 **Products → URL Deep-link Parameter** 里改
  （留空则关闭该功能）。
- 参数值必须是 `product_brand` 分类法里真实存在的 term slug（如 `chanel`、
  `louis-vuitton`）；无效或 `all` 会回落到「全部」。
- 页面首屏渲染即按该品牌筛选，品牌按钮同步高亮，排序 / 分页仍走 AJAX。
- 前端页面 URL 里多个品牌网格会同时被该参数筛选（通常是想要的行为）。

## 文件结构

```
elementor-brand-grid/
├── elementor-brand-grid.php             插件主文件（注册小部件、AJAX、资源、品牌缓存）
├── includes/
│   └── class-widget-brand-grid.php      小部件类（控件 + 渲染 + WP_Query + AJAX 渲染逻辑）
├── assets/
│   ├── css/brand-grid.css               前端样式（筛选栏 / 排序 / 卡片 / 响应式）
│   └── js/brand-grid.js                 前端交互（AJAX 品牌筛选排序 + 加购反馈）
└── README.md
```

## 性能说明

- 产品查询使用 `WP_Query`，配合 `wc_get_product()`（走 WooCommerce 对象缓存）。
- 品牌列表使用按分类法区分的 `transient` 缓存（12 小时），并在分类项增删改时自动失效。
