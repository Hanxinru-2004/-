<?php
/**
 * Brand Grid widget.
 *
 * @package Elementor_Brand_Grid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;

/**
 * Brand Grid widget.
 *
 * Renders a WooCommerce product grid with a horizontal brand filter, a sort
 * dropdown and a live product count. Filtering / sorting is handled over AJAX
 * so the page never refreshes. The card markup reuses the "Elementor Product
 * Grid" layout (hover image swap, badges, slide-up action bar).
 */
class EBG_Brand_Grid_Widget extends Widget_Base {

	/**
	 * Allowed sort keys and their WP_Query orderby mapping.
	 *
	 * @var array
	 */
	const SORT_OPTIONS = [
		'default'    => 'default',
		'random'     => 'random',
		'featured'   => 'featured',
		'price-asc'  => 'price-asc',
		'price-desc' => 'price-desc',
		'date'       => 'date',
	];

	/**
	 * Get widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'ebg-brand-grid';
	}

	/**
	 * Get widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Brand Grid', 'elementor-brand-grid' );
	}

	/**
	 * Get widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	/**
	 * Get widget categories.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ebg-brand' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'brand', 'product', 'grid', 'woocommerce', 'filter', 'sort', 'luxury', 'ebg' ];
	}

	/**
	 * Register controls.
	 */
	protected function register_controls() {
		$this->register_content_controls();
		$this->register_toolbar_style_controls();
		$this->register_grid_style_controls();
		$this->register_card_style_controls();
		$this->register_brand_style_controls();
		$this->register_name_style_controls();
		$this->register_condition_style_controls();
		$this->register_price_style_controls();
		$this->register_badge_style_controls();
		$this->register_wishlist_style_controls();
		$this->register_button_style_controls();
	}

	/**
	 * Content controls.
	 */
	protected function register_content_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Products', 'elementor-brand-grid' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'columns',
			[
				'label'       => esc_html__( 'Products per Row', 'elementor-brand-grid' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					'3' => esc_html__( '3', 'elementor-brand-grid' ),
					'4' => esc_html__( '4', 'elementor-brand-grid' ),
					'6' => esc_html__( '6', 'elementor-brand-grid' ),
				],
				'default'     => '4',
				'description' => esc_html__( 'Products per row on desktop. Tablet (2) and mobile (1) are handled responsively.', 'elementor-brand-grid' ),
				'selectors'   => [
					'{{WRAPPER}} .ebg-grid' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));',
				],
			]
		);

		$this->add_control(
			'rows',
			[
				'label'       => esc_html__( 'Products per Column (Rows)', 'elementor-brand-grid' ),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 1,
				'max'         => 20,
				'step'        => 1,
				'default'     => 2,
				'description' => esc_html__( 'Products shown per page = rows × products per row.', 'elementor-brand-grid' ),
			]
		);

		$this->add_control(
			'show_brands',
			[
				'label'        => esc_html__( 'Show Brand Filter', 'elementor-brand-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-brand-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-brand-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_sorting',
			[
				'label'        => esc_html__( 'Show Sort Dropdown', 'elementor-brand-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-brand-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-brand-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_count',
			[
				'label'        => esc_html__( 'Show Product Count', 'elementor-brand-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-brand-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-brand-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_add_to_cart',
			[
				'label'        => esc_html__( 'Show Add to Bag Button', 'elementor-brand-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-brand-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-brand-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_view_details',
			[
				'label'        => esc_html__( 'Show View Details Link', 'elementor-brand-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-brand-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-brand-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_wishlist',
			[
				'label'        => esc_html__( 'Show Wishlist Button', 'elementor-brand-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-brand-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-brand-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'brand_taxonomy',
			[
				'label'       => esc_html__( 'Brand Taxonomy Slug', 'elementor-brand-grid' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'product_brand',
				'description' => esc_html__( 'The taxonomy that stores the brand (e.g. product_brand). Used for the brand filter and the card brand label.', 'elementor-brand-grid' ),
			]
		);

		$this->add_control(
			'url_param',
			[
				'label'       => esc_html__( 'URL Deep-link Parameter', 'elementor-brand-grid' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'ebg_brand',
				'description' => esc_html__( 'A query parameter name that deep-links straight to one brand on page load, e.g. ?ebg_brand=chanel. Leave the value out to disable.', 'elementor-brand-grid' ),
			]
		);

		$this->add_control(
			'condition_attr',
			[
				'label'       => esc_html__( 'Condition Attribute', 'elementor-brand-grid' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'condition',
				'description' => esc_html__( 'The product attribute that stores condition (e.g. condition or pa_condition).', 'elementor-brand-grid' ),
			]
		);

		$this->add_control(
			'year_attr',
			[
				'label'       => esc_html__( 'Year Attribute', 'elementor-brand-grid' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'year',
				'description' => esc_html__( 'The product attribute that stores the year (e.g. year or pa_year).', 'elementor-brand-grid' ),
			]
		);

		$this->add_control(
			'show_authenticated',
			[
				'label'        => esc_html__( 'Show Authenticated Badge', 'elementor-brand-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-brand-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-brand-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'new_in_days',
			[
				'label'       => esc_html__( 'New In (days)', 'elementor-brand-grid' ),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 365,
				'step'        => 1,
				'default'     => 30,
				'description' => esc_html__( 'Products published within this many days get the "New In" badge. 0 disables it.', 'elementor-brand-grid' ),
			]
		);

		$this->add_control(
			'limited_tag',
			[
				'label'       => esc_html__( 'Limited Tag Slug', 'elementor-brand-grid' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'limited',
				'description' => esc_html__( 'Products with this product tag get the "Limited" badge.', 'elementor-brand-grid' ),
			]
		);

		$this->add_control(
			'show_brand',
			[
				'label'        => esc_html__( 'Show Brand Label', 'elementor-brand-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-brand-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-brand-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_name',
			[
				'label'        => esc_html__( 'Show Name', 'elementor-brand-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-brand-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-brand-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_condition',
			[
				'label'        => esc_html__( 'Show Condition & Dots', 'elementor-brand-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-brand-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-brand-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_price',
			[
				'label'        => esc_html__( 'Show Price', 'elementor-brand-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'elementor-brand-grid' ),
				'label_off'    => esc_html__( 'Hide', 'elementor-brand-grid' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Add a standard "Hover" tab to a style section.
	 *
	 * Provides hover controls for typography (font + text decoration),
	 * text color, background color, line style (solid/double/wavy) and border.
	 *
	 * @param string $name     Unique control-name prefix (one per section).
	 * @param string $selector CSS selector for the hovered element (without :hover).
	 * @param bool   $important Append !important to color / decoration overrides
	 *                          (used where a theme forces its own hover styles).
	 */
	protected function add_hover_controls( $name, $selector, $important = false ) {
		$imp = $important ? ' !important' : '';

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => $name . '_hover_typography',
				'label'    => esc_html__( 'Hover Typography', 'elementor-brand-grid' ),
				'selector' => '{{WRAPPER}} ' . $selector . ':hover',
			]
		);

		$this->add_control(
			$name . '_hover_color',
			[
				'label'     => esc_html__( 'Hover Text Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ' . $selector . ':hover' => 'color: {{VALUE}}' . $imp . ';',
				],
			]
		);

		$this->add_control(
			$name . '_hover_background',
			[
				'label'     => esc_html__( 'Hover Background', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ' . $selector . ':hover' => 'background-color: {{VALUE}} !important;',
				],
			]
		);

		$this->add_control(
			$name . '_hover_text_decoration_style',
			[
				'label'       => esc_html__( 'Hover Line Style', 'elementor-brand-grid' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'solid',
				'description' => esc_html__( 'For wavy / double lines, set Hover Typography → Text Decoration to Underline first.', 'elementor-brand-grid' ),
				'options'     => [
					'solid'  => esc_html__( 'Solid', 'elementor-brand-grid' ),
					'double' => esc_html__( 'Double (双横线)', 'elementor-brand-grid' ),
					'wavy'   => esc_html__( 'Wavy (波浪线)', 'elementor-brand-grid' ),
					'dashed' => esc_html__( 'Dashed', 'elementor-brand-grid' ),
					'dotted' => esc_html__( 'Dotted', 'elementor-brand-grid' ),
				],
				'selectors' => [
					'{{WRAPPER}} ' . $selector . ':hover' => 'text-decoration-style: {{VALUE}}' . $imp . ';',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => $name . '_hover_border',
				'label'    => esc_html__( 'Hover Border', 'elementor-brand-grid' ),
				'selector' => '{{WRAPPER}} ' . $selector . ':hover',
			]
		);
	}

	/**
	 * Toolbar (brand filter + sort + count) style controls.
	 */
	protected function register_toolbar_style_controls() {
		$this->start_controls_section(
			'section_toolbar_style',
			[
				'label' => esc_html__( 'Filter & Sort', 'elementor-brand-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'toolbar_tabs' );

		$this->start_controls_tab(
			'toolbar_normal',
			[ 'label' => esc_html__( 'Normal', 'elementor-brand-grid' ) ]
		);

		$this->add_control(
			'brand_active_heading',
			[
				'label' => esc_html__( 'Brand — Active', 'elementor-brand-grid' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'brand_active_background',
			[
				'label'     => esc_html__( 'Background', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .ebg-brand-btn.is-active' => 'background-color: {{VALUE}}; border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'brand_active_color',
			[
				'label'     => esc_html__( 'Text Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ebg-brand-btn.is-active' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'brand_inactive_heading',
			[
				'label'     => esc_html__( 'Brand — Inactive', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'brand_inactive_color',
			[
				'label'     => esc_html__( 'Text Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .ebg-brand-btn' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'brand_inactive_border',
			[
				'label'     => esc_html__( 'Border Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(0, 0, 0, 0.15)',
				'selectors' => [
					'{{WRAPPER}} .ebg-brand-btn' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'brand_filter_typography',
				'label'    => esc_html__( 'Brand Filter Typography', 'elementor-brand-grid' ),
				'selector' => '{{WRAPPER}} .ebg-brand-btn',
				'default'  => [
					'font_family'    => 'Jost',
					'font_size'      => [ 'unit' => 'px', 'size' => 11 ],
					'font_weight'    => '300',
					'letter_spacing' => [ 'unit' => 'px', 'size' => 1.54 ],
					'text_transform' => 'uppercase',
				],
			]
		);

		$this->add_control(
			'count_heading',
			[
				'label'     => esc_html__( 'Count', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'count_color',
			[
				'label'     => esc_html__( 'Text Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#888888',
				'selectors' => [
					'{{WRAPPER}} .ebg-count' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'count_typography',
				'label'    => esc_html__( 'Count Typography', 'elementor-brand-grid' ),
				'selector' => '{{WRAPPER}} .ebg-count',
				'default'  => [
					'font_family'    => 'Jost',
					'font_size'      => [ 'unit' => 'px', 'size' => 12 ],
					'font_weight'    => '400',
					'letter_spacing' => [ 'unit' => 'px', 'size' => 0.48 ],
				],
			]
		);

		$this->add_control(
			'sort_heading',
			[
				'label'     => esc_html__( 'Sort Dropdown', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'sort_color',
			[
				'label'     => esc_html__( 'Text Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .ebg-sort' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'sort_background',
			[
				'label'     => esc_html__( 'Background', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ebg-sort' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'sort_border',
			[
				'label'     => esc_html__( 'Border Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(0, 0, 0, 0.15)',
				'selectors' => [
					'{{WRAPPER}} .ebg-sort' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'sort_typography',
				'label'    => esc_html__( 'Sort Typography', 'elementor-brand-grid' ),
				'selector' => '{{WRAPPER}} .ebg-sort',
				'default'  => [
					'font_family'    => 'Jost',
					'font_size'      => [ 'unit' => 'px', 'size' => 12 ],
					'font_weight'    => '400',
					'letter_spacing' => [ 'unit' => 'px', 'size' => 0.96 ],
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'toolbar_hover',
			[ 'label' => esc_html__( 'Hover', 'elementor-brand-grid' ) ]
		);

		$this->add_hover_controls( 'toolbar', '.ebg-brand-btn', true );

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Grid style controls.
	 */
	protected function register_grid_style_controls() {
		$this->start_controls_section(
			'section_grid_style',
			[
				'label' => esc_html__( 'Grid', 'elementor-brand-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'grid_tabs' );

		$this->start_controls_tab(
			'grid_normal',
			[ 'label' => esc_html__( 'Normal', 'elementor-brand-grid' ) ]
		);

		$this->add_responsive_control(
			'column_gap',
			[
				'label'      => esc_html__( 'Column Gap', 'elementor-brand-grid' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'size' => 24,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .ebg-grid' => 'column-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'row_gap',
			[
				'label'      => esc_html__( 'Row Gap', 'elementor-brand-grid' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'size' => 56,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .ebg-grid' => 'row-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'grid_hover',
			[ 'label' => esc_html__( 'Hover', 'elementor-brand-grid' ) ]
		);

		$this->add_hover_controls( 'grid', '.ebg-grid' );

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Card style controls.
	 */
	protected function register_card_style_controls() {
		$this->start_controls_section(
			'section_card_style',
			[
				'label' => esc_html__( 'Card', 'elementor-brand-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'card_tabs' );

		$this->start_controls_tab(
			'card_normal',
			[ 'label' => esc_html__( 'Normal', 'elementor-brand-grid' ) ]
		);

		$this->add_control(
			'image_background',
			[
				'label'     => esc_html__( 'Image Background', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f5f0e8',
				'selectors' => [
					'{{WRAPPER}} .ebg-image-wrapper' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'card_background',
			[
				'label'     => esc_html__( 'Card Background', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .ebg-product' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'card_border',
				'label'    => esc_html__( 'Border', 'elementor-brand-grid' ),
				'selector' => '{{WRAPPER}} .ebg-product',
				'default'  => [
					'border' => 'none',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'card_hover',
			[ 'label' => esc_html__( 'Hover', 'elementor-brand-grid' ) ]
		);

		$this->add_hover_controls( 'card', '.ebg-product' );

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Brand label style controls.
	 */
	protected function register_brand_style_controls() {
		$this->start_controls_section(
			'section_brand_style',
			[
				'label' => esc_html__( 'Brand Label', 'elementor-brand-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'brand_tabs' );

		$this->start_controls_tab(
			'brand_normal',
			[ 'label' => esc_html__( 'Normal', 'elementor-brand-grid' ) ]
		);

		$this->add_control(
			'brand_color',
			[
				'label'     => esc_html__( 'Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1a5c3a',
				'selectors' => [
					'{{WRAPPER}} .ebg-brand' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'brand_typography',
				'label'    => esc_html__( 'Typography', 'elementor-brand-grid' ),
				'selector' => '{{WRAPPER}} .ebg-brand',
				'default'  => [
					'font_family'    => 'Jost',
					'font_size'      => [ 'unit' => 'px', 'size' => 10 ],
					'font_weight'    => '500',
					'letter_spacing' => [ 'unit' => 'px', 'size' => 2 ],
					'text_transform' => 'uppercase',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'brand_hover',
			[ 'label' => esc_html__( 'Hover', 'elementor-brand-grid' ) ]
		);

		$this->add_hover_controls( 'brand', '.ebg-brand' );

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Name style controls.
	 */
	protected function register_name_style_controls() {
		$this->start_controls_section(
			'section_name_style',
			[
				'label' => esc_html__( 'Name', 'elementor-brand-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'name_tabs' );

		$this->start_controls_tab(
			'name_normal',
			[ 'label' => esc_html__( 'Normal', 'elementor-brand-grid' ) ]
		);

		$this->add_control(
			'name_color',
			[
				'label'     => esc_html__( 'Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .ebg-name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'name_typography',
				'label'    => esc_html__( 'Typography', 'elementor-brand-grid' ),
				'selector' => '{{WRAPPER}} .ebg-name',
				'default'  => [
					'font_family'    => 'Cormorant Garamond',
					'font_size'      => [ 'unit' => 'px', 'size' => 17 ],
					'font_weight'    => '500',
					'letter_spacing' => [ 'unit' => 'px', 'size' => 0.34 ],
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'name_hover',
			[ 'label' => esc_html__( 'Hover', 'elementor-brand-grid' ) ]
		);

		$this->add_hover_controls( 'name', '.ebg-name' );

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Condition style controls.
	 */
	protected function register_condition_style_controls() {
		$this->start_controls_section(
			'section_condition_style',
			[
				'label' => esc_html__( 'Condition', 'elementor-brand-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'condition_tabs' );

		$this->start_controls_tab(
			'condition_normal',
			[ 'label' => esc_html__( 'Normal', 'elementor-brand-grid' ) ]
		);

		$this->add_control(
			'condition_color',
			[
				'label'     => esc_html__( 'Text Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#999999',
				'selectors' => [
					'{{WRAPPER}} .ebg-condition' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'condition_typography',
				'label'    => esc_html__( 'Typography', 'elementor-brand-grid' ),
				'selector' => '{{WRAPPER}} .ebg-condition',
				'default'  => [
					'font_family'    => 'Jost',
					'font_size'      => [ 'unit' => 'px', 'size' => 11 ],
					'font_weight'    => '300',
					'letter_spacing' => [ 'unit' => 'px', 'size' => 0.44 ],
				],
			]
		);

		$this->add_control(
			'dot_on_color',
			[
				'label'     => esc_html__( 'Dot Active Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1a5c3a',
				'selectors' => [
					'{{WRAPPER}} .ebg-dot--on' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'dot_off_color',
			[
				'label'     => esc_html__( 'Dot Inactive Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(0, 0, 0, 0.12)',
				'selectors' => [
					'{{WRAPPER}} .ebg-dot--off' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'condition_hover',
			[ 'label' => esc_html__( 'Hover', 'elementor-brand-grid' ) ]
		);

		$this->add_hover_controls( 'condition', '.ebg-condition' );

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Price style controls.
	 */
	protected function register_price_style_controls() {
		$this->start_controls_section(
			'section_price_style',
			[
				'label' => esc_html__( 'Price', 'elementor-brand-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'price_tabs' );

		$this->start_controls_tab(
			'price_normal',
			[ 'label' => esc_html__( 'Normal', 'elementor-brand-grid' ) ]
		);

		$this->add_control(
			'sale_heading',
			[
				'label' => esc_html__( 'Current Price', 'elementor-brand-grid' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'sale_color',
			[
				'label'     => esc_html__( 'Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .ebg-sale' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'sale_typography',
				'label'    => esc_html__( 'Typography', 'elementor-brand-grid' ),
				'selector' => '{{WRAPPER}} .ebg-sale',
				'default'  => [
					'font_family'    => 'Cormorant Garamond',
					'font_size'      => [ 'unit' => 'px', 'size' => 18 ],
					'font_weight'    => '500',
					'letter_spacing' => [ 'unit' => 'px', 'size' => 0.72 ],
				],
			]
		);

		$this->add_control(
			'regular_heading',
			[
				'label'     => esc_html__( 'Regular Price', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'regular_color',
			[
				'label'     => esc_html__( 'Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#bbbbbb',
				'selectors' => [
					'{{WRAPPER}} .ebg-regular' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'regular_typography',
				'label'    => esc_html__( 'Typography', 'elementor-brand-grid' ),
				'selector' => '{{WRAPPER}} .ebg-regular',
				'default'  => [
					'font_family'     => 'Cormorant Garamond',
					'font_size'       => [ 'unit' => 'px', 'size' => 14 ],
					'font_weight'     => '400',
					'letter_spacing'  => [ 'unit' => 'px', 'size' => 0.56 ],
					'text_decoration' => 'line-through',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'price_hover',
			[ 'label' => esc_html__( 'Hover', 'elementor-brand-grid' ) ]
		);

		$this->add_hover_controls( 'price', '.ebg-sale' );

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Badge style controls.
	 */
	protected function register_badge_style_controls() {
		$this->start_controls_section(
			'section_badge_style',
			[
				'label' => esc_html__( 'Badges', 'elementor-brand-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'badge_tabs' );

		$this->start_controls_tab(
			'badge_normal',
			[ 'label' => esc_html__( 'Normal', 'elementor-brand-grid' ) ]
		);

		$this->add_control(
			'auth_badge_background',
			[
				'label'     => esc_html__( 'Authenticated Background', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(255,255,255,0.92)',
				'selectors' => [
					'{{WRAPPER}} .ebg-badge--auth' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'auth_badge_color',
			[
				'label'     => esc_html__( 'Authenticated Text', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1a5c3a',
				'selectors' => [
					'{{WRAPPER}} .ebg-badge--auth' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'new_badge_background',
			[
				'label'     => esc_html__( 'New In Background', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .ebg-badge--new' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'limited_badge_background',
			[
				'label'     => esc_html__( 'Limited Background', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1a5c3a',
				'selectors' => [
					'{{WRAPPER}} .ebg-badge--limited' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'badge_typography',
				'label'    => esc_html__( 'Typography', 'elementor-brand-grid' ),
				'selector' => '{{WRAPPER}} .ebg-badge',
				'default'  => [
					'font_family'    => 'Jost',
					'font_size'      => [ 'unit' => 'px', 'size' => 9 ],
					'font_weight'    => '500',
					'letter_spacing' => [ 'unit' => 'px', 'size' => 1.26 ],
					'text_transform' => 'uppercase',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'badge_hover',
			[ 'label' => esc_html__( 'Hover', 'elementor-brand-grid' ) ]
		);

		$this->add_hover_controls( 'badge', '.ebg-badge' );

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Wishlist (heart) button style controls.
	 */
	protected function register_wishlist_style_controls() {
		$this->start_controls_section(
			'section_wishlist_style',
			[
				'label' => esc_html__( 'Wishlist Button', 'elementor-brand-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'wishlist_icon',
			[
				'label'   => esc_html__( 'Icon (Normal)', 'elementor-brand-grid' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value'   => 'far fa-heart',
					'library' => 'fa-regular',
				],
			]
		);

		$this->add_control(
			'wishlist_icon_active',
			[
				'label'   => esc_html__( 'Icon (Active / Added)', 'elementor-brand-grid' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value'   => 'fas fa-heart',
					'library' => 'fa-solid',
				],
			]
		);

		$this->add_control(
			'wishlist_icon_size',
			[
				'label'      => esc_html__( 'Icon Size', 'elementor-brand-grid' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 12,
						'max' => 40,
					],
				],
				'default'    => [
					'size' => 18,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .ebg-wishlist-btn i'   => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ebg-wishlist-btn svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'wishlist_style_tabs' );

		$this->start_controls_tab(
			'wishlist_normal',
			[ 'label' => esc_html__( 'Normal', 'elementor-brand-grid' ) ]
		);

		$this->add_control(
			'wishlist_color',
			[
				'label'     => esc_html__( 'Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .ebg-wishlist-btn'     => 'color: {{VALUE}};',
					'{{WRAPPER}} .ebg-wishlist-btn svg' => 'fill: {{VALUE}}; stroke: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'wishlist_hover',
			[ 'label' => esc_html__( 'Hover', 'elementor-brand-grid' ) ]
		);

		$this->add_control(
			'wishlist_hover_color',
			[
				'label'     => esc_html__( 'Hover Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .ebg-wishlist-btn:hover'     => 'color: {{VALUE}};',
					'{{WRAPPER}} .ebg-wishlist-btn:hover svg' => 'fill: {{VALUE}}; stroke: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Action bar style controls.
	 */
	protected function register_button_style_controls() {
		$this->start_controls_section(
			'section_button_style',
			[
				'label' => esc_html__( 'Action Bar', 'elementor-brand-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'action_tabs' );

		$this->start_controls_tab(
			'action_normal',
			[ 'label' => esc_html__( 'Normal', 'elementor-brand-grid' ) ]
		);

		$this->add_control(
			'action_bar_background',
			[
				'label'     => esc_html__( 'Background', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(255,255,255,0.95)',
				'selectors' => [
					'{{WRAPPER}} .ebg-actions' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'action_typography',
				'label'    => esc_html__( 'Typography', 'elementor-brand-grid' ),
				'selector' => '{{WRAPPER}} .ebg-action',
				'default'  => [
					'font_family'    => 'Jost',
					'font_size'      => [ 'unit' => 'px', 'size' => 10 ],
					'font_weight'    => '500',
					'letter_spacing' => [ 'unit' => 'px', 'size' => 1.4 ],
					'text_transform' => 'uppercase',
				],
			]
		);

		$this->add_control(
			'action_color',
			[
				'label'     => esc_html__( 'Text Color', 'elementor-brand-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .ebg-action' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'action_hover',
			[ 'label' => esc_html__( 'Hover', 'elementor-brand-grid' ) ]
		);

		$this->add_hover_controls( 'action', '.ebg-action' );

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Render the widget.
	 */
	protected function render() {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return;
		}

		$settings = $this->get_settings_for_display();
		$s        = $this->get_sanitized_settings( $settings );

		// Initial load: all brands by default, or the brand requested through the
		// deep-link query parameter (e.g. ?ebg_brand=chanel). This lets the brand
		// bar / brand logos elsewhere on the site jump straight to one brand.
		$brand  = $this->get_deep_link_brand( $s );
		$result = $this->render_products( $settings, $brand, 'default', 1 );

		// Pass the full widget settings to the frontend so AJAX can re-render
		// the grid with identical options after a filter / sort change.
		$json = wp_json_encode( $settings );
		if ( false === $json ) {
			$json = '[]';
		}

		echo '<div class="ebg-brand-grid" data-settings="' . esc_attr( $json ) . '">';

		if ( $s['show_brands'] || $s['show_sorting'] || $s['show_count'] ) {
			echo '<div class="ebg-toolbar">';

			if ( $s['show_brands'] ) {
				echo $this->render_brand_filter( $s['brand_taxonomy'], $brand ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}

			if ( $s['show_sorting'] || $s['show_count'] ) {
				echo '<div class="ebg-toolbar-right">';

				if ( $s['show_count'] ) {
					echo '<span class="ebg-count">' . $this->render_count_label( $result['count'] ) . '</span>';
				}

				if ( $s['show_sorting'] ) {
					echo $this->render_sort_dropdown( 'default' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}

				echo '</div>';
			}

			echo '</div>';
		}

		echo '<div class="ebg-grid">' . $result['html'] . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		echo '<div class="ebg-pagination">';
		echo $this->render_pagination( $result['page'], $result['pages'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</div>';

		echo '</div>';
	}

	/**
	 * Render the product cards for a given filter / sort / page and return
	 * their HTML, the total matching count and pagination info. Shared by the
	 * initial render and the AJAX handler so both always produce identical
	 * markup.
	 *
	 * @param array  $settings Raw widget settings (from get_settings_for_display()
	 *                         or decoded from the AJAX request).
	 * @param string $brand    Product brand slug, or 'all'.
	 * @param string $orderby  Sort key from SORT_OPTIONS.
	 * @param int    $paged    Current page (1-based).
	 * @return array{html: string, count: int, pages: int, page: int}
	 */
	public function render_products( $settings, $brand = 'all', $orderby = 'default', $paged = 1 ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return [
				'html'  => '',
				'count' => 0,
				'pages' => 1,
				'page'  => 1,
			];
		}

		$paged = max( 1, (int) $paged );
		$s     = $this->get_sanitized_settings( $settings );
		$query = new \WP_Query( $this->get_query_args( $s, $brand, $orderby, $paged ) );

		$html = '';
		foreach ( $query->posts as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( $product ) {
				$html .= $this->render_product( $product, $s );
			}
		}

		$count = (int) $query->found_posts;
		$pages = max( 1, (int) $query->max_num_pages );
		wp_reset_postdata();

		return [
			'html'  => $html,
			'count' => $count,
			'pages' => $pages,
			'page'  => $paged,
		];
	}

	/**
	 * Build the WP_Query arguments for the current filter / sort / page.
	 *
	 * @param array  $settings Sanitized widget settings.
	 * @param string $brand    Product brand slug, or 'all'.
	 * @param string $orderby  Sort key from SORT_OPTIONS.
	 * @param int    $paged    Current page (1-based).
	 * @return array WP_Query arguments.
	 */
	protected function get_query_args( $settings, $brand, $orderby, $paged = 1 ) {
		$args = [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => $settings['per_page'],
			'paged'          => max( 1, (int) $paged ),
			'fields'         => 'ids',
			'orderby'        => 'date',
			'order'          => 'DESC',
			'tax_query'      => [], // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
			'meta_query'     => [], // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		];

		// Brand filter (skip for 'all').
		if ( 'all' !== $brand && '' !== $brand && '' !== $settings['brand_taxonomy'] ) {
			$args['tax_query'][] = [
				'taxonomy' => $settings['brand_taxonomy'],
				'field'    => 'slug',
				'terms'    => $brand,
			];
		}

		// Only allow known sort keys; anything else falls back to the default order.
		if ( ! isset( self::SORT_OPTIONS[ $orderby ] ) ) {
			$orderby = 'default';
		}

		switch ( $orderby ) {
			case 'price-asc':
				$args['meta_key'] = '_price';
				$args['orderby']  = 'meta_value_num';
				$args['order']    = 'ASC';
				break;

			case 'price-desc':
				$args['meta_key'] = '_price';
				$args['orderby']  = 'meta_value_num';
				$args['order']    = 'DESC';
				break;

			case 'date':
				$args['orderby'] = 'date';
				$args['order']   = 'DESC';
				break;

			case 'random':
				$args['orderby'] = 'rand';
				break;

			case 'default':
				// Sort by product upload time, earliest first.
				$args['orderby'] = 'date';
				$args['order']   = 'ASC';
				break;

			case 'featured':
			default:
				// "Featured" shows the curated selection of featured products,
				// newest first. product_visibility is WooCommerce's private
				// taxonomy where featured products live.
				$args['tax_query'][] = [
					'taxonomy' => 'product_visibility',
					'field'    => 'slug',
					'terms'    => 'featured',
				];
				$args['orderby'] = 'date';
				$args['order']   = 'DESC';
				break;
		}

		return $args;
	}

	/**
	 * Sanitize / normalize raw widget settings into a flat, typed array used by
	 * both the renderer and the query builder.
	 *
	 * @param array $settings Raw settings.
	 * @return array Sanitized settings.
	 */
	protected function get_sanitized_settings( $settings ) {
		$settings = is_array( $settings ) ? $settings : [];

		$columns = isset( $settings['columns'] ) ? (string) $settings['columns'] : '4';
		$columns = in_array( $columns, [ '3', '4', '6' ], true ) ? $columns : '4';
		$rows    = min( 20, max( 1, absint( isset( $settings['rows'] ) ? $settings['rows'] : 2 ) ) );

		return [
			'columns'            => $columns,
			'rows'               => $rows,
			'per_page'           => (int) $columns * $rows,
			'show_brands'        => 'yes' === ( isset( $settings['show_brands'] ) ? $settings['show_brands'] : 'yes' ),
			'show_sorting'       => 'yes' === ( isset( $settings['show_sorting'] ) ? $settings['show_sorting'] : 'yes' ),
			'show_count'         => 'yes' === ( isset( $settings['show_count'] ) ? $settings['show_count'] : 'yes' ),
			'show_add_to_cart'   => 'yes' === ( isset( $settings['show_add_to_cart'] ) ? $settings['show_add_to_cart'] : 'yes' ),
			'show_view_details'  => 'yes' === ( isset( $settings['show_view_details'] ) ? $settings['show_view_details'] : 'yes' ),
			'show_wishlist'      => 'yes' === ( isset( $settings['show_wishlist'] ) ? $settings['show_wishlist'] : 'yes' ),
			'show_authenticated' => 'yes' === ( isset( $settings['show_authenticated'] ) ? $settings['show_authenticated'] : 'yes' ),
			'wishlist_icon'        => isset( $settings['wishlist_icon'] ) ? $settings['wishlist_icon'] : [ 'value' => 'far fa-heart', 'library' => 'fa-regular' ],
			'wishlist_icon_active' => isset( $settings['wishlist_icon_active'] ) ? $settings['wishlist_icon_active'] : [ 'value' => 'fas fa-heart', 'library' => 'fa-solid' ],
			'show_brand'         => 'yes' === ( isset( $settings['show_brand'] ) ? $settings['show_brand'] : 'yes' ),
			'show_name'          => 'yes' === ( isset( $settings['show_name'] ) ? $settings['show_name'] : 'yes' ),
			'show_condition'     => 'yes' === ( isset( $settings['show_condition'] ) ? $settings['show_condition'] : 'yes' ),
			'show_price'         => 'yes' === ( isset( $settings['show_price'] ) ? $settings['show_price'] : 'yes' ),
			'brand_taxonomy'     => sanitize_text_field( isset( $settings['brand_taxonomy'] ) ? $settings['brand_taxonomy'] : 'product_brand' ),
			'url_param'          => sanitize_key( isset( $settings['url_param'] ) ? $settings['url_param'] : 'ebg_brand' ),
			'condition_attr'     => sanitize_text_field( isset( $settings['condition_attr'] ) ? $settings['condition_attr'] : 'condition' ),
			'year_attr'          => sanitize_text_field( isset( $settings['year_attr'] ) ? $settings['year_attr'] : 'year' ),
			'limited_tag'        => sanitize_text_field( isset( $settings['limited_tag'] ) ? $settings['limited_tag'] : 'limited' ),
			'new_in_days'        => absint( isset( $settings['new_in_days'] ) ? $settings['new_in_days'] : 30 ),
		];
	}

	/**
	 * Get all non-empty WooCommerce product brands, cached in a transient.
	 *
	 * @param string $taxonomy Brand taxonomy slug.
	 * @return \WP_Term[] Brand terms.
	 */
	protected function get_product_brands( $taxonomy ) {
		$taxonomy = trim( (string) $taxonomy );

		if ( '' === $taxonomy || ! taxonomy_exists( $taxonomy ) ) {
			return [];
		}

		$transient = 'ebg_brands_' . $taxonomy;
		$cached    = get_transient( $transient );

		if ( false !== $cached ) {
			return is_array( $cached ) ? $cached : [];
		}

		$terms = get_terms(
			[
				'taxonomy'   => $taxonomy,
				'hide_empty' => true,
				'orderby'    => 'name',
				'order'      => 'ASC',
			]
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			$terms = [];
		}

		set_transient( $transient, $terms, 12 * HOUR_IN_SECONDS );

		return $terms;
	}

	/**
	 * Resolve the brand to show on initial load from the deep-link query
	 * parameter, or 'all' when absent / invalid / not a real brand.
	 *
	 * @param array $settings Sanitized widget settings.
	 * @return string Brand slug, or 'all'.
	 */
	protected function get_deep_link_brand( $settings ) {
		$param = isset( $settings['url_param'] ) ? $settings['url_param'] : 'ebg_brand';

		if ( '' === $param || ! isset( $_GET[ $param ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return 'all';
		}

		$slug = sanitize_title( wp_unslash( $_GET[ $param ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		if ( '' === $slug || 'all' === $slug ) {
			return 'all';
		}

		if ( '' !== $settings['brand_taxonomy'] && taxonomy_exists( $settings['brand_taxonomy'] ) ) {
			$term = get_term_by( 'slug', $slug, $settings['brand_taxonomy'] );

			if ( $term instanceof \WP_Term ) {
				return $slug;
			}
		}

		return 'all';
	}

	/**
	 * Render the brand filter buttons.
	 *
	 * @param string $taxonomy Brand taxonomy slug.
	 * @param string $active   Currently active brand slug ('all' for all).
	 * @return string Brand filter markup.
	 */
	protected function render_brand_filter( $taxonomy, $active = 'all' ) {
		$terms = $this->get_product_brands( $taxonomy );

		$html  = '<div class="ebg-brands">';
		$html .= '<button type="button" class="ebg-brand-btn' . ( 'all' === $active ? ' is-active' : '' ) . '" data-brand="all">' . esc_html__( 'All', 'elementor-brand-grid' ) . '</button>';

		foreach ( $terms as $term ) {
			$html .= '<button type="button" class="ebg-brand-btn' . ( $term->slug === $active ? ' is-active' : '' ) . '" data-brand="' . esc_attr( $term->slug ) . '">' . esc_html( $term->name ) . '</button>';
		}

		$html .= '</div>';

		return $html;
	}

	/**
	 * Render the sort dropdown.
	 *
	 * @param string $active Currently active sort key.
	 * @return string Sort dropdown markup.
	 */
	protected function render_sort_dropdown( $active = 'default' ) {
		$options = [
			'default'    => esc_html__( 'Default Order', 'elementor-brand-grid' ),
			'random'     => esc_html__( 'Random', 'elementor-brand-grid' ),
			'featured'   => esc_html__( 'Featured', 'elementor-brand-grid' ),
			'price-asc'  => esc_html__( 'Price: Low to High', 'elementor-brand-grid' ),
			'price-desc' => esc_html__( 'Price: High to Low', 'elementor-brand-grid' ),
			'date'       => esc_html__( 'Newest', 'elementor-brand-grid' ),
		];

		$html = '<div class="ebg-sort-wrap"><select class="ebg-sort" aria-label="' . esc_attr__( 'Sort products', 'elementor-brand-grid' ) . '">';

		foreach ( $options as $value => $label ) {
			$html .= '<option value="' . esc_attr( $value ) . '"' . selected( $active, $value, false ) . '>' . $label . '</option>';
		}

		$html .= '</select></div>';

		return $html;
	}

	/**
	 * Render pagination links (1 2 3 … n).
	 *
	 * @param int $current Current page.
	 * @param int $total   Total number of pages.
	 * @return string Pagination markup (empty when only one page).
	 */
	public function render_pagination( $current, $total ) {
		$current = max( 1, (int) $current );
		$total   = max( 1, (int) $total );

		if ( $total <= 1 ) {
			return '';
		}

		$pages = $this->build_pagination_range( $current, $total );

		$html = '<nav class="ebg-pagination" aria-label="' . esc_attr__( 'Products pagination', 'elementor-brand-grid' ) . '">';

		foreach ( $pages as $page ) {
			if ( is_int( $page ) ) {
				$html .= '<button type="button" class="ebg-page-btn' . ( $page === $current ? ' is-active' : '' ) . '" data-page="' . $page . '">' . $page . '</button>';
			} else {
				$html .= '<span class="ebg-page-dots">' . $page . '</span>';
			}
		}

		$html .= '</nav>';

		return $html;
	}

	/**
	 * Build a windowed pagination range with ellipses, e.g. [1, '…', 4, 5, 6, '…', 10].
	 *
	 * @param int $current Current page.
	 * @param int $total   Total number of pages.
	 * @return array List of page numbers (int) and ellipsis strings (string).
	 */
	protected function build_pagination_range( $current, $total ) {
		$current = max( 1, (int) $current );
		$total   = max( 1, (int) $total );

		// Show every page when there are few.
		if ( $total <= 7 ) {
			return range( 1, $total );
		}

		$range = [ 1 ];

		$start = max( 2, $current - 1 );
		$end   = min( $total - 1, $current + 1 );

		if ( $start > 2 ) {
			$range[] = '…';
		}

		for ( $i = $start; $i <= $end; $i++ ) {
			$range[] = $i;
		}

		if ( $end < $total - 1 ) {
			$range[] = '…';
		}

		$range[] = $total;

		return $range;
	}

	/**
	 * Build the "X pieces" count label.
	 *
	 * @param int $count Product count.
	 * @return string Count label.
	 */
	public function render_count_label( $count ) {
		return sprintf(
			/* translators: %s: number of products. */
			_n( '%s piece', '%s pieces', $count, 'elementor-brand-grid' ),
			number_format_i18n( $count )
		);
	}

	/**
	 * Render a single product card.
	 *
	 * @param \WC_Product $product  Product object.
	 * @param array       $settings Sanitized widget settings.
	 * @return string Product card markup.
	 */
	protected function render_product( $product, $settings ) {
		$id        = $product->get_id();
		$name      = $product->get_name();
		$permalink = get_permalink( $id );

		$image_id = $product->get_image_id();
		$gallery  = $product->get_gallery_image_ids();
		$hover_id = ! empty( $gallery[0] ) ? $gallery[0] : 0;

		$wrapper_class = 'ebg-image-wrapper' . ( $hover_id ? ' has-hover' : '' );

		$html  = '<div class="ebg-product">';
		$html .= '<div class="' . esc_attr( $wrapper_class ) . '">';

		$html .= '<a class="ebg-link" href="' . esc_url( $permalink ) . '">';

		if ( $image_id ) {
			$main_src = wp_get_attachment_image_url( $image_id, 'large' );
			if ( $main_src ) {
				$html .= '<img class="ebg-img ebg-img--primary" src="' . esc_url( $main_src ) . '" alt="' . esc_attr( $name ) . '" loading="lazy">';
			}
		}

		if ( $hover_id ) {
			$hover_src = wp_get_attachment_image_url( $hover_id, 'large' );
			if ( $hover_src ) {
				$html .= '<img class="ebg-img ebg-img--hover" src="' . esc_url( $hover_src ) . '" alt="' . esc_attr( $name ) . '" loading="lazy">';
			}
		}

		$html .= '</a>'; // .ebg-link

		if ( $settings['show_authenticated'] ) {
			$html .= '<div class="ebg-badge ebg-badge--auth">';
			$html .= $this->svg_auth();
			$html .= '<span>' . esc_html__( 'Authenticated', 'elementor-brand-grid' ) . '</span>';
			$html .= '</div>';
		}

		$badge        = $this->get_new_badge( $product, $settings );
		$has_wishlist = ( $settings['show_wishlist'] && shortcode_exists( 'woosw' ) );

		if ( '' !== $badge || $has_wishlist ) {
			$html .= '<div class="ebg-badges-right">';

			if ( '' !== $badge ) {
				$badge_class = 'limited' === $badge ? 'ebg-badge--limited' : 'ebg-badge--new';
				$badge_text  = 'limited' === $badge ? __( 'Limited', 'elementor-brand-grid' ) : __( 'New In', 'elementor-brand-grid' );
				$html       .= '<div class="ebg-badge ' . esc_attr( $badge_class ) . '">';
				$html       .= '<span>' . esc_html( $badge_text ) . '</span>';
				$html       .= '</div>';
			}

			if ( $has_wishlist ) {
				/*
				 * `woosw-btn-has-icon` is REQUIRED — do not remove it. WPC Smart
				 * Wishlist's frontend.js refreshes every `.woosw-btn` on page load and
				 * executes `$('.woosw-btn:not(.woosw-btn-has-icon)').text( ... )`, which
				 * would delete our heart spans and leave the "Add to wishlist" label.
				 * Declaring the button as "has icon" sends woosw down its icon branch,
				 * which only touches `.woosw-btn-icon` / `.woosw-btn-text` children (we
				 * render neither), so no text is ever written and our hearts survive.
				 * The `woosw-added` state class is applied outside that branch, so the
				 * empty/filled heart swap keeps working.
				 */
				$html .= '<button class="woosw-btn woosw-btn-has-icon woosw-btn-' . esc_attr( $id ) . ' ebg-wishlist-btn" data-id="' . esc_attr( $id ) . '" aria-label="' . esc_attr__( 'Wishlist', 'elementor-brand-grid' ) . '">';
				$html .= '<span class="ebg-wishlist-icon ebg-wishlist-icon--off">';
				ob_start();
				\Elementor\Icons_Manager::render_icon( $settings['wishlist_icon'], [ 'aria-hidden' => 'true' ] );
				$html .= ob_get_clean();
				$html .= '</span>';
				$html .= '<span class="ebg-wishlist-icon ebg-wishlist-icon--on">';
				ob_start();
				\Elementor\Icons_Manager::render_icon( $settings['wishlist_icon_active'], [ 'aria-hidden' => 'true' ] );
				$html .= ob_get_clean();
				$html .= '</span>';
				$html .= '</button>';
			}

			$html .= '</div>';
		}

		if ( $settings['show_add_to_cart'] || $settings['show_view_details'] ) {
			$html .= '<div class="ebg-actions">';

			if ( $settings['show_add_to_cart'] ) {
				// Variable / non-purchasable products cannot be added over AJAX
				// (they need a variation or are unavailable). Link those to the
				// product page; simple purchasable products keep AJAX add-to-cart.
				$ajaxable = $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock();
				$classes  = 'ebg-action ebg-action--bag ebg-add-to-bag';
				$href     = $ajaxable ? $product->add_to_cart_url() : $permalink;
				$attrs    = ' rel="nofollow"';

				if ( $ajaxable ) {
					$classes .= ' add_to_cart_button ajax_add_to_cart';
					$attrs   .= ' data-product_id="' . esc_attr( $id ) . '" data-quantity="1"';
				}

				$html .= '<a class="' . esc_attr( $classes ) . '" href="' . esc_url( $href ) . '"' . $attrs . '>';
				$html .= $this->svg_bag();
				$html .= '<span class="ebg-action-text">' . esc_html__( 'Add to Bag', 'elementor-brand-grid' ) . '</span>';
				$html .= '</a>';
			}

			if ( $settings['show_add_to_cart'] && $settings['show_view_details'] ) {
				$html .= '<span class="ebg-sep">|</span>';
			}

			if ( $settings['show_view_details'] ) {
				$html .= '<a class="ebg-action ebg-action--view" href="' . esc_url( $permalink ) . '">';
				$html .= $this->svg_view();
				$html .= '<span>' . esc_html__( 'View Details', 'elementor-brand-grid' ) . '</span>';
				$html .= '</a>';
			}

			$html .= '</div>'; // .ebg-actions
		}

		$html .= '</div>'; // .ebg-image-wrapper

		$html .= '<div class="ebg-content">';

		if ( $settings['show_brand'] ) {
			$brand = $this->get_brand( $product, $settings['brand_taxonomy'] );
			if ( '' !== $brand ) {
				$html .= '<div class="ebg-brand">' . esc_html( $brand ) . '</div>';
			}
		}

		if ( $settings['show_name'] ) {
			$html .= '<h3 class="ebg-name">' . esc_html( $name ) . '</h3>';
		}

		if ( $settings['show_condition'] ) {
			$condition_text = $this->get_condition_text( $product, $settings );
			$dots           = $this->get_condition_dots( $this->get_attribute( $product, $settings['condition_attr'] ) );

			if ( '' !== $condition_text ) {
				$html .= '<div class="ebg-condition">' . esc_html( $condition_text ) . '</div>';
			}

			if ( $dots > 0 ) {
				$html .= $this->render_dots( $dots );
			}
		}

		if ( $settings['show_price'] ) {
			$price_html = $this->render_price( $product );
			if ( '' !== $price_html ) {
				$html .= '<div class="ebg-price">' . $price_html . '</div>';
			}
		}

		$html .= '</div>'; // .ebg-content

		$html .= '</div>'; // .ebg-product

		return $html;
	}

	/**
	 * Get the brand term name.
	 *
	 * @param \WC_Product $product Product object.
	 * @param string      $tax     Taxonomy slug.
	 * @return string Brand name, or empty string.
	 */
	protected function get_brand( $product, $tax ) {
		$tax = trim( (string) $tax );
		if ( '' === $tax ) {
			return '';
		}

		$terms = get_the_terms( $product->get_id(), $tax );
		if ( $terms && ! is_wp_error( $terms ) && ! empty( $terms[0] ) ) {
			return $terms[0]->name;
		}

		return '';
	}

	/**
	 * Get a product attribute value.
	 *
	 * @param \WC_Product $product Product object.
	 * @param string      $attr    Attribute name.
	 * @return string Attribute value, or empty string.
	 */
	protected function get_attribute( $product, $attr ) {
		$attr = trim( (string) $attr );
		if ( '' === $attr ) {
			return '';
		}

		$value = $product->get_attribute( $attr );

		return is_string( $value ) ? trim( $value ) : '';
	}

	/**
	 * Build the condition text ("Excellent · 2022").
	 *
	 * @param \WC_Product $product  Product object.
	 * @param array       $settings Sanitized widget settings.
	 * @return string Condition text, or empty string.
	 */
	protected function get_condition_text( $product, $settings ) {
		$condition = $this->get_attribute( $product, $settings['condition_attr'] );
		$year      = $this->get_attribute( $product, $settings['year_attr'] );

		if ( '' !== $condition && '' !== $year ) {
			return $condition . ' · ' . $year;
		}

		if ( '' !== $condition ) {
			return $condition;
		}

		if ( '' !== $year ) {
			return $year;
		}

		return '';
	}

	/**
	 * Map a condition label to a number of active dots (0-10).
	 *
	 * @param string $condition Condition label.
	 * @return int Active dot count.
	 */
	protected function get_condition_dots( $condition ) {
		$map = apply_filters(
			'ebg_condition_dots_map',
			[
				'new'        => 10,
				'unused'     => 10,
				'pristine'   => 10,
				'never worn' => 10,
				'excellent'  => 9,
				'like new'   => 9,
				'like-new'   => 9,
				'very good'  => 8,
				'very-good'  => 8,
				'good'       => 7,
				'fair'       => 5,
				'poor'       => 3,
			]
		);

		$key = strtolower( trim( (string) $condition ) );

		if ( '' === $key ) {
			return 0;
		}

		return isset( $map[ $key ] ) ? (int) $map[ $key ] : 8;
	}

	/**
	 * Render the 10 condition dots.
	 *
	 * @param int $active Number of active dots.
	 * @return string Dots markup.
	 */
	protected function render_dots( $active ) {
		$active = max( 0, min( 10, (int) $active ) );
		$html   = '<div class="ebg-dots">';

		for ( $i = 0; $i < 10; $i++ ) {
			$class = $i < $active ? 'ebg-dot ebg-dot--on' : 'ebg-dot ebg-dot--off';
			$html .= '<span class="' . $class . '"></span>';
		}

		$html .= '</div>';

		return $html;
	}

	/**
	 * Determine the "New In" / "Limited" badge for a product.
	 *
	 * @param \WC_Product $product  Product object.
	 * @param array       $settings Sanitized widget settings.
	 * @return string 'limited', 'new', or empty string.
	 */
	protected function get_new_badge( $product, $settings ) {
		$limited_tag = trim( (string) $settings['limited_tag'] );
		if ( '' !== $limited_tag && has_term( $limited_tag, 'product_tag', $product->get_id() ) ) {
			return 'limited';
		}

		$days = absint( $settings['new_in_days'] );
		if ( $days < 1 ) {
			return '';
		}

		$created = $product->get_date_created();
		if ( ! $created ) {
			return '';
		}

		$created_ts = $created->getTimestamp();

		return ( time() - $created_ts ) < ( $days * DAY_IN_SECONDS ) ? 'new' : '';
	}

	/**
	 * Render the product price (current + regular).
	 *
	 * @param \WC_Product $product Product object.
	 * @return string Price markup, or empty string.
	 */
	protected function render_price( $product ) {
		$regular = $product->get_regular_price();
		$sale    = $product->get_sale_price();

		if ( '' !== $sale && '' !== $regular && (float) $sale < (float) $regular ) {
			return '<span class="ebg-sale">' . wc_price( $sale ) . '</span><span class="ebg-regular">' . wc_price( $regular ) . '</span>';
		}

		$price = $product->get_price();
		if ( '' === $price ) {
			return '';
		}

		return '<span class="ebg-sale">' . wc_price( $price ) . '</span>';
	}

	/**
	 * Authenticated (shield) icon SVG.
	 *
	 * @return string Inline SVG.
	 */
	protected function svg_auth() {
		return '<svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M8.33333 5.41667C8.33333 7.5 6.875 8.54167 5.14167 9.14583C5.0509 9.17659 4.95231 9.17512 4.8625 9.14167C3.125 8.54167 1.66667 7.5 1.66667 5.41667V2.5C1.66667 2.38949 1.71057 2.28351 1.78871 2.20537C1.86685 2.12723 1.97283 2.08333 2.08333 2.08333C2.91667 2.08333 3.95833 1.58333 4.68333 0.95C4.77161 0.874583 4.8839 0.833146 5 0.833146C5.1161 0.833146 5.22839 0.874583 5.31667 0.95C6.04583 1.5875 7.08333 2.08333 7.91667 2.08333C8.02717 2.08333 8.13315 2.12723 8.21129 2.20537C8.28943 2.28351 8.33333 2.38949 8.33333 2.5V5.41667Z" stroke="#1A5C3A" stroke-width="0.833333" stroke-linecap="round" stroke-linejoin="round"/><path d="M3.75 5L4.58333 5.83333L6.25 4.16667" stroke="#1A5C3A" stroke-width="0.833333" stroke-linecap="round" stroke-linejoin="round"/></svg>';
	}

	/**
	 * Shopping bag icon SVG.
	 *
	 * @return string Inline SVG.
	 */
	protected function svg_bag() {
		return '<svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M3.25 1.08333L1.625 3.25V10.8333C1.625 11.1207 1.73914 11.3962 1.9423 11.5994C2.14547 11.8025 2.42102 11.9167 2.70833 11.9167H10.2917C10.579 11.9167 10.8545 11.8025 11.0577 11.5994C11.2609 11.3962 11.375 11.1207 11.375 10.8333V3.25L9.75 1.08333H3.25Z" stroke="currentColor" stroke-width="0.8125" stroke-linecap="round" stroke-linejoin="round"/><path d="M1.625 3.25H11.375" stroke="currentColor" stroke-width="0.8125" stroke-linecap="round" stroke-linejoin="round"/><path d="M8.66667 5.41667C8.66667 5.9913 8.43839 6.5424 8.03206 6.94873C7.62574 7.35506 7.07464 7.58333 6.5 7.58333C5.92536 7.58333 5.37426 7.35506 4.96793 6.94873C4.56161 6.5424 4.33333 5.9913 4.33333 5.41667" stroke="currentColor" stroke-width="0.8125" stroke-linecap="round" stroke-linejoin="round"/></svg>';
	}

	/**
	 * Eye (view details) icon SVG.
	 *
	 * @return string Inline SVG.
	 */
	protected function svg_view() {
		return '<svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M1.11692 6.3115C1.07177 6.43311 1.07177 6.56689 1.11692 6.6885C1.55659 7.75458 2.3029 8.6661 3.26125 9.30751C4.2196 9.94892 5.34682 10.2913 6.5 10.2913C7.65318 10.2913 8.7804 9.94892 9.73875 9.30751C10.6971 8.6661 11.4434 7.75458 11.8831 6.6885C11.9282 6.56689 11.9282 6.43311 11.8831 6.3115C11.4434 5.24542 10.6971 4.3339 9.73875 3.69249C8.7804 3.05108 7.65318 2.70867 6.5 2.70867C5.34682 2.70867 4.2196 3.05108 3.26125 3.69249C2.3029 4.3339 1.55659 5.24542 1.11692 6.3115Z" stroke="currentColor" stroke-width="0.8125" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.5 8.125C7.39746 8.125 8.125 7.39746 8.125 6.5C8.125 5.60254 7.39746 4.875 6.5 4.875C5.60254 4.875 4.875 5.60254 4.875 6.5C4.875 7.39746 5.60254 8.125 6.5 8.125Z" stroke="currentColor" stroke-width="0.8125" stroke-linecap="round" stroke-linejoin="round"/></svg>';
	}
}
