<?php
/**
 * Plugin Name:       Elementor Shop Grid
 * Plugin URI:        https://example.com/elementor-shop-grid
 * Description:       A WooCommerce shop grid widget for Elementor with a category filter, sort dropdown, live product count, hover image swap and AJAX add-to-cart. Designed around a pre-owned luxury aesthetic (Cormorant Garamond + Jost + deep-green accent).
 * Version:           1.2.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       elementor-shop-grid
 * Domain Path:       /languages
 *
 * @package Elementor_Shop_Grid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'ESG_VERSION', '1.2.0' );
define( 'ESG_PATH', plugin_dir_path( __FILE__ ) );
define( 'ESG_URL', plugin_dir_url( __FILE__ ) );

/**
 * Register the widget.
 *
 * The widget class is required lazily so this file can be loaded even when
 * Elementor is not active (the action never fires in that case).
 *
 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
 */
function esg_register_widget( $widgets_manager ) {
	require_once ESG_PATH . 'includes/class-widget-shop-grid.php';
	$widgets_manager->register( new ESG_Shop_Grid_Widget() );
}
add_action( 'elementor/widgets/register', 'esg_register_widget' );

/**
 * Register a custom Elementor category for this widget.
 *
 * @param \Elementor\Elements_Manager $elements_manager Elementor elements manager.
 */
function esg_register_category( $elements_manager ) {
	$elements_manager->add_category(
		'esg-shop',
		[
			'title' => esc_html__( 'Shop', 'elementor-shop-grid' ),
			'icon'  => 'fa fa-plug',
		]
	);
}
add_action( 'elementor/elements/categories_registered', 'esg_register_category' );

/**
 * Enqueue the frontend stylesheet.
 */
function esg_enqueue_styles() {
	wp_enqueue_style(
		'esg-shop-grid',
		ESG_URL . 'assets/css/shop-grid.css',
		[],
		ESG_VERSION
	);
}
add_action( 'elementor/frontend/after_enqueue_styles', 'esg_enqueue_styles' );

/**
 * Enqueue the Google Fonts used by the design spec (Cormorant Garamond + Jost).
 * Hooked to both frontend and the Elementor preview so the editor shows the
 * correct typefaces.
 */
function esg_enqueue_fonts() {
	wp_enqueue_style(
		'esg-google-fonts',
		'https://fonts.googleapis.com/css2?family=Jost:wght@300;400;500&family=Cormorant+Garamond:wght@400;500&display=swap',
		[],
		null
	);
}
add_action( 'wp_enqueue_scripts', 'esg_enqueue_fonts' );
add_action( 'elementor/preview/enqueue_styles', 'esg_enqueue_fonts' );

/**
 * Enqueue WooCommerce's AJAX add-to-cart script (reused, not duplicated) plus
 * this widget's own enhancement script, and localize the AJAX endpoint.
 */
function esg_enqueue_scripts() {
	if ( function_exists( 'WC' ) ) {
		wp_enqueue_script( 'wc-add-to-cart' );
	}

	wp_enqueue_script(
		'esg-shop-grid',
		ESG_URL . 'assets/js/shop-grid.js',
		[ 'jquery' ],
		ESG_VERSION,
		true
	);

	wp_localize_script(
		'esg-shop-grid',
		'esgShopGrid',
		[
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'esg_shop_grid' ),
			'i18n'    => [
				'error' => esc_html__( 'Something went wrong. Please try again.', 'elementor-shop-grid' ),
			],
		]
	);
}
add_action( 'elementor/frontend/after_enqueue_scripts', 'esg_enqueue_scripts' );

/**
 * AJAX handler: filter / sort the product grid without a page refresh.
 *
 * Reuses the widget's own render logic so the frontend and AJAX markup always
 * stay in sync.
 */
function esg_ajax_filter_products() {
	check_ajax_referer( 'esg_shop_grid', 'nonce' );

	if ( ! function_exists( 'wc_get_product' ) ) {
		wp_send_json_error();
	}

	$category = isset( $_POST['category'] ) ? sanitize_text_field( wp_unslash( $_POST['category'] ) ) : 'all';
	$orderby  = isset( $_POST['orderby'] ) ? sanitize_key( wp_unslash( $_POST['orderby'] ) ) : 'default';
	$paged    = isset( $_POST['paged'] ) ? absint( $_POST['paged'] ) : 1;
	$raw      = isset( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

	// Settings may arrive as a JSON string (from the data-settings attribute).
	$settings = is_array( $raw ) ? $raw : json_decode( (string) $raw, true );
	if ( ! is_array( $settings ) ) {
		$settings = [];
	}

	require_once ESG_PATH . 'includes/class-widget-shop-grid.php';

	$widget = new ESG_Shop_Grid_Widget();
	$result = $widget->render_products( $settings, $category, $orderby, $paged );

	wp_send_json_success(
		[
			'html'        => $result['html'],
			'count'       => $result['count'],
			'count_label' => $widget->render_count_label( $result['count'] ),
			'pagination'  => $widget->render_pagination( $result['page'], $result['pages'] ),
		]
	);
}
add_action( 'wp_ajax_esg_filter_products', 'esg_ajax_filter_products' );
add_action( 'wp_ajax_nopriv_esg_filter_products', 'esg_ajax_filter_products' );

/**
 * Invalidate the cached product-category list whenever a category changes.
 *
 * @param int    $term_id  Term ID.
 * @param int    $tt_id    Term taxonomy ID.
 * @param string $taxonomy Taxonomy slug.
 */
function esg_flush_category_cache( $term_id, $tt_id, $taxonomy ) {
	if ( 'product_cat' === $taxonomy ) {
		delete_transient( 'esg_product_categories' );
	}
}
add_action( 'created_term', 'esg_flush_category_cache', 10, 3 );
add_action( 'edited_term', 'esg_flush_category_cache', 10, 3 );
add_action( 'delete_term', 'esg_flush_category_cache', 10, 3 );

/**
 * Show an admin notice when required plugins are missing.
 */
function esg_admin_notice() {
	$missing = [];

	if ( ! did_action( 'elementor/loaded' ) ) {
		$missing[] = 'Elementor';
	}

	if ( ! class_exists( 'WooCommerce' ) ) {
		$missing[] = 'WooCommerce';
	}

	if ( empty( $missing ) ) {
		return;
	}

	printf(
		'<div class="notice notice-warning"><p>%s</p></div>',
		esc_html(
			sprintf(
				/* translators: %s: comma-separated list of missing plugins. */
				__( 'Elementor Shop Grid requires %s to be installed and activated.', 'elementor-shop-grid' ),
				implode( ' and ', $missing )
			)
		)
	);
}
add_action( 'admin_notices', 'esg_admin_notice' );
