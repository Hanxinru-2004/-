<?php
/**
 * Uninstall handler — removes the per-product highlight meta.
 *
 * @package WebsiteProductGrid
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

$post_ids = $wpdb->get_col(
	"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status IN ('publish', 'draft', 'pending', 'private', 'trash')"
);

if ( ! empty( $post_ids ) ) {
	foreach ( $post_ids as $post_id ) {
		delete_post_meta( absint( $post_id ), '_wpg_highlights' );
	}
}

// Nothing else is stored globally, so there is no option to delete.
