<?php
/**
 * Per-product "highlights" custom field stored on the WooCommerce product.
 *
 * Highlights are entered as one bullet per line on the product edit screen and
 * rendered as the dot-list inside the Website Product Grid widget.
 *
 * @package WebsiteProductGrid
 */

defined( 'ABSPATH' ) || exit;

/**
 * Product highlights meta box and storage.
 */
class WPG_Product_Meta {

	const META_KEY = '_wpg_highlights';

	/**
	 * Hook into WordPress.
	 */
	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post_product', array( __CLASS__, 'save' ), 20, 2 );
	}

	/**
	 * Add the highlights meta box to the product edit screen.
	 */
	public static function add_meta_box() {
		add_meta_box(
			'wpg_product_highlights',
			__( 'Product Highlights', 'website-product-grid' ),
			array( __CLASS__, 'render_meta_box' ),
			'product',
			'normal',
			'default'
		);
	}

	/**
	 * Render the meta box content.
	 *
	 * @param \WP_Post $post Current post object.
	 */
	public static function render_meta_box( $post ) {
		wp_nonce_field( 'wpg_highlights_save', 'wpg_highlights_nonce' );

		$value = self::get_highlights( $post->ID );
		$value = implode( "\n", $value );

		echo '<p class="description">'
			. esc_html__( 'Enter one product highlight per line. These bullets are shown inside the Website Product Grid widget (each line becomes a dot-point).', 'website-product-grid' )
			. '</p>';
		echo '<textarea name="wpg_highlights" rows="6" class="large-text" style="width:100%">'
			. esc_textarea( $value )
			. '</textarea>';
	}

	/**
	 * Save the highlights when the product is saved.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post object.
	 */
	public static function save( $post_id, $post ) {
		// Nonce.
		if ( ! isset( $_POST['wpg_highlights_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wpg_highlights_nonce'] ) ), 'wpg_highlights_save' ) ) {
			return;
		}
		// Autosave / revisions.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}
		// Capability.
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$raw   = isset( $_POST['wpg_highlights'] ) ? sanitize_textarea_field( wp_unslash( $_POST['wpg_highlights'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$raw   = is_string( $raw ) ? $raw : '';
		$lines = self::normalize_lines( $raw );

		if ( ! empty( $lines ) ) {
			update_post_meta( $post_id, self::META_KEY, $lines );
		} else {
			delete_post_meta( $post_id, self::META_KEY );
		}
	}

	/**
	 * Read the highlights for a product as an array of strings.
	 *
	 * @param int $product_id Product ID.
	 * @return string[] Array of highlight lines (may be empty).
	 */
	public static function get_highlights( $product_id ) {
		$product_id = absint( $product_id );
		if ( $product_id <= 0 ) {
			return array();
		}

		$value = get_post_meta( $product_id, self::META_KEY, true );

		// Stored as an array (current format).
		if ( is_array( $value ) ) {
			return array_values( array_filter( array_map( 'trim', $value ) ) );
		}

		// Legacy string format (newline-separated).
		if ( is_string( $value ) && '' !== $value ) {
			return self::normalize_lines( $value );
		}

		return array();
	}

	/**
	 * Split a newline-separated string into a trimmed, non-empty array of lines.
	 *
	 * @param string $raw Raw textarea value.
	 * @return string[]
	 */
	private static function normalize_lines( $raw ) {
		$lines = preg_split( '/\r\n|\r|\n/', (string) $raw );
		$lines = array_map( 'trim', (array) $lines );
		$lines = array_filter( $lines, 'strlen' );
		return array_values( $lines );
	}
}
