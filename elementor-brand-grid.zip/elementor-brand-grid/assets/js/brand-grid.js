/*
 * Elementor Brand Grid — AJAX brand filter + sort + pagination, live product
 * count, and a static "Add to Bag" button after a successful AJAX add-to-cart.
 */
(function ($) {
	'use strict';

	/**
	 * Keep the "Add to Bag" button static after a successful AJAX add and remove
	 * the "View cart" link WooCommerce inserts (the same pattern used by the
	 * standalone Product Grid widget).
	 */
	$(document.body).on('added_to_cart', function (event, fragments, cartHash, button) {
		var $btn = $(button);
		if (!$btn.hasClass('ebg-add-to-bag')) {
			return;
		}

		$btn.closest('.ebg-actions').find('.added_to_cart.wc-forward').remove();
		$btn.removeClass('added loading');
	});

	/**
	 * Brand filter button click.
	 */
	$(document).on('click', '.ebg-brand-btn', function () {
		var $btn = $(this);
		var $root = $btn.closest('.ebg-brand-grid');

		if ($btn.hasClass('is-active')) {
			return;
		}

		$root.find('.ebg-brand-btn').removeClass('is-active');
		$btn.addClass('is-active');

		fetchProducts($root, $btn.data('brand'), $root.find('.ebg-sort').val(), 1);
	});

	/**
	 * Sort dropdown change.
	 */
	$(document).on('change', '.ebg-sort', function () {
		var $root = $(this).closest('.ebg-brand-grid');
		var activeBrand = $root.find('.ebg-brand-btn.is-active').data('brand') || 'all';

		fetchProducts($root, activeBrand, $(this).val(), 1);
	});

	/**
	 * Pagination button click.
	 */
	$(document).on('click', '.ebg-page-btn', function () {
		var $root = $(this).closest('.ebg-brand-grid');
		var page = parseInt($(this).data('page'), 10) || 1;
		var activeBrand = $root.find('.ebg-brand-btn.is-active').data('brand') || 'all';
		var orderby = $root.find('.ebg-sort').val() || 'default';

		fetchProducts($root, activeBrand, orderby, page);
	});

	/**
	 * Request a filtered / sorted / paginated product list and swap the grid
	 * and pagination in place.
	 *
	 * @param {jQuery} $root   The .ebg-brand-grid wrapper.
	 * @param {string} brand   Active brand slug ('all' for everything).
	 * @param {string} orderby Active sort key.
	 * @param {number} paged   Active page (1-based).
	 */
	function fetchProducts($root, brand, orderby, paged) {
		paged = paged || 1;

		var $grid = $root.find('.ebg-grid');
		var $pagination = $root.find('.ebg-pagination');
		var settings = {};

		try {
			settings = JSON.parse($root.attr('data-settings') || '{}');
		} catch (e) {
			settings = {};
		}

		$grid.addClass('is-loading');

		$.post(ebgBrandGrid.ajaxUrl, {
			action: 'ebg_filter_products',
			nonce: ebgBrandGrid.nonce,
			brand: brand,
			orderby: orderby,
			paged: paged,
			settings: settings
		}).done(function (response) {
			if (response && response.success) {
				$grid.html(response.data.html);

				// Attach the wishlist guard to the freshly rendered cards and ask
				// WPC Smart Wishlist to re-sync their added/removed state.
				ebgHardenWishlistButtons($grid);
				$(document.body).trigger('woosw_refresh_data');

				if ($pagination.length && typeof response.data.pagination !== 'undefined') {
					$pagination.html(response.data.pagination);
				}

				var $count = $root.find('.ebg-count');
				if ($count.length && typeof response.data.count_label !== 'undefined') {
					$count.text(response.data.count_label);
				}
			} else {
				window.console && console.error(response && response.data ? response.data : 'Brand grid AJAX error');
			}
		}).fail(function () {
			window.alert && alert(ebgBrandGrid.i18n.error);
		}).always(function () {
			$grid.removeClass('is-loading');
		});
	}

	/* ---------------- Wishlist: icon only, never text ----------------
	 *
	 * WPC Smart Wishlist's woosw_refresh_buttons() runs on every page load and
	 * executes `$('.woosw-btn:not(.woosw-btn-has-icon)').text( ... )`. jQuery
	 * .text() replaces every child node, so it deleted our two heart spans and
	 * left a bare "Add to wishlist" / "Browse wishlist" text node behind.
	 *
	 * The primary fix is the `woosw-btn-has-icon` class in the button markup,
	 * which makes woosw skip this button. This observer is the backstop: if any
	 * plugin or theme ever writes into the button again, the text is removed and
	 * the hearts are put back.
	 */

	var EBG_HARDENED = 'ebgWishlistHardened';

	/**
	 * Remove foreign nodes from a wishlist button and restore its heart spans.
	 *
	 * Loop-safe: the observer is disconnected before we mutate and reconnected
	 * afterwards, so our own changes are never re-observed.
	 */
	function ebgSanitizeWishlistButton(btn, observer, icons) {
		if (observer) {
			observer.disconnect();
		}

		// Drop text nodes ("Add to wishlist") and any element that is not ours
		// (woosw's text span / tick / spinner, a theme label, ...).
		for (var i = btn.childNodes.length - 1; i >= 0; i--) {
			var node = btn.childNodes[i];
			var isOurs = node.nodeType === 1 &&
				node.className &&
				String(node.className).indexOf('ebg-wishlist-icon') !== -1;

			if (!isOurs) {
				btn.removeChild(node);
			}
		}

		// Put the hearts back if they were wiped.
		if (icons.off && !icons.off.parentNode) {
			btn.appendChild(icons.off);
		}
		if (icons.on && !icons.on.parentNode) {
			btn.appendChild(icons.on);
		}

		// Kill native and hint.css tooltips too — the icon should stand alone.
		btn.removeAttribute('title');
		btn.removeAttribute('data-hint');

		if (observer) {
			observer.observe(btn, { childList: true, characterData: true, subtree: true });
		}
	}

	/**
	 * Attach the guard to every wishlist button inside `root` that lacks one.
	 *
	 * @param {jQuery|Element|Document} root Optional scope. Defaults to document.
	 */
	function ebgHardenWishlistButtons(root) {
		$(root || document).find('.ebg-wishlist-btn').addBack('.ebg-wishlist-btn').each(function () {
			var btn = this;
			var $btn = $(btn);

			if ($btn.data(EBG_HARDENED)) {
				return;
			}
			$btn.data(EBG_HARDENED, true);

			// Cache the heart nodes so they can be re-attached if they get wiped.
			var icons = {
				off: btn.querySelector('.ebg-wishlist-icon--off'),
				on: btn.querySelector('.ebg-wishlist-icon--on')
			};

			var observer = null;
			if (window.MutationObserver) {
				observer = new MutationObserver(function () {
					ebgSanitizeWishlistButton(btn, observer, icons);
				});
			}

			// First pass also starts the observer.
			ebgSanitizeWishlistButton(btn, observer, icons);
		});
	}

	/**
	 * Mirror woosw's added/removed state onto the button.
	 *
	 * @param {number|string} productId Product ID woosw reported.
	 * @param {boolean}       added     Whether it is now in the wishlist.
	 */
	function ebgSyncWishlistState(productId, added) {
		$('.ebg-wishlist-btn[data-id="' + productId + '"]').toggleClass('woosw-added', !!added);
	}

	$(function () {
		ebgHardenWishlistButtons(document);
	});

	// woosw repaints buttons over AJAX after page load — re-check each time.
	$(document.body).on('woosw_buttons_refreshed woosw_refresh_button_id woosw_data_refreshed', function () {
		ebgHardenWishlistButtons(document);
	});

	$(document.body).on('woosw_add', function (event, productId) {
		ebgSyncWishlistState(productId, true);
	});

	$(document.body).on('woosw_remove', function (event, productId) {
		ebgSyncWishlistState(productId, false);
	});

	// Elementor re-renders the widget in the editor; those fresh buttons need
	// their own guard.
	function ebgRegisterElementorHook() {
		if (!window.elementorFrontend || !elementorFrontend.hooks) {
			return false;
		}

		elementorFrontend.hooks.addAction(
			'frontend/element_ready/ebg-brand-grid.default',
			function ($scope) {
				ebgHardenWishlistButtons($scope);
			}
		);

		return true;
	}

	if (!ebgRegisterElementorHook()) {
		$(window).on('elementor/frontend/init', ebgRegisterElementorHook);
	}
})(jQuery);
