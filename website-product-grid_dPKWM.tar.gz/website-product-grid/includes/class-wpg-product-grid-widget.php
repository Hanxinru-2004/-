<?php
/**
 * Elementor widget: WooCommerce product grid with per-product highlights.
 *
 * @package WebsiteProductGrid
 */

defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Widget_Base;

/**
 * Product Grid widget.
 */
class WPG_Product_Grid_Widget extends Widget_Base {

	/**
	 * Widget name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'wpg_product_grid';
	}

	/**
	 * Widget title.
	 *
	 * @return string
	 */
	public function get_title() {
		return __( 'Product Grid', 'website-product-grid' );
	}

	/**
	 * Widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	/**
	 * Widget category.
	 *
	 * @return string[]
	 */
	public function get_categories() {
		return array( 'website-product-grid' );
	}

	/**
	 * Widget keywords.
	 *
	 * @return string[]
	 */
	public function get_keywords() {
		return array( 'woocommerce', 'product', 'products', 'grid', 'highlights', 'shop' );
	}

	/**
	 * Frontend styles this widget depends on.
	 *
	 * @return string[]
	 */
	public function get_style_depends() {
		return array( 'wpg-product-grid' );
	}

	/**
	 * Register widget controls.
	 */
	protected function register_controls() {
		$this->register_source_controls();
		$this->register_layout_controls();
		$this->register_content_controls();
		$this->register_heading_controls();
		$this->register_highlights_controls();
		$this->register_style_controls();
	}

	/**
	 * Products source controls.
	 */
	protected function register_source_controls() {
		$this->start_controls_section(
			'section_source',
			array(
				'label' => __( 'Products Source', 'website-product-grid' ),
			)
		);

		$this->add_control(
			'source',
			array(
				'label'   => __( 'Product Source', 'website-product-grid' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'category',
				'options' => array(
					'category' => __( 'Filter by category', 'website-product-grid' ),
					'ids'      => __( 'Choose products manually', 'website-product-grid' ),
					'latest'   => __( 'Latest products', 'website-product-grid' ),
				),
			)
		);

		$this->add_control(
			'product_categories',
			array(
				'label'       => __( 'Product Categories', 'website-product-grid' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'options'     => $this->get_product_category_options(),
				'default'     => array(),
				'condition'   => array( 'source' => 'category' ),
			)
		);

		$this->add_control(
			'product_ids',
			array(
				'label'       => __( 'Product IDs', 'website-product-grid' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => '123, 456, 789',
				'default'     => '',
				'description' => __( 'Enter the product IDs to display, separated by commas. The order you type them is preserved.', 'website-product-grid' ),
				'condition'   => array( 'source' => 'ids' ),
			)
		);

		$this->add_control(
			'products_count',
			array(
				'label'   => __( 'Number of Products', 'website-product-grid' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 4,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			)
		);

		$this->add_control(
			'orderby',
			array(
				'label'     => __( 'Order By', 'website-product-grid' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'date',
				'options'   => array(
					'date'       => __( 'Date', 'website-product-grid' ),
					'title'      => __( 'Title', 'website-product-grid' ),
					'menu_order' => __( 'Menu Order', 'website-product-grid' ),
					'modified'   => __( 'Last Modified', 'website-product-grid' ),
					'rand'       => __( 'Random', 'website-product-grid' ),
				),
				'condition' => array( 'source!' => 'ids' ),
			)
		);

		$this->add_control(
			'order',
			array(
				'label'     => __( 'Order', 'website-product-grid' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'desc',
				'options'   => array(
					'asc'  => __( 'Ascending', 'website-product-grid' ),
					'desc' => __( 'Descending', 'website-product-grid' ),
				),
				'condition' => array( 'source!' => 'ids' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Layout controls.
	 */
	protected function register_layout_controls() {
		$this->start_controls_section(
			'section_layout',
			array(
				'label' => __( 'Layout', 'website-product-grid' ),
			)
		);

		$this->add_control(
			'columns',
			array(
				'label'   => __( 'Columns (Desktop)', 'website-product-grid' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '4',
				'options' => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
				),
			)
		);

		$this->add_control(
			'columns_tablet',
			array(
				'label'   => __( 'Columns (Tablet)', 'website-product-grid' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '2',
				'options' => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
				),
			)
		);

		$this->add_control(
			'columns_mobile',
			array(
				'label'   => __( 'Columns (Mobile)', 'website-product-grid' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => '1',
					'2' => '2',
				),
			)
		);

		$this->add_responsive_control(
			'grid_gap',
			array(
				'label'     => __( 'Columns Gap', 'website-product-grid' ),
				'type'      => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em', 'rem' ),
				'range'     => array(
					'px' => array( 'min' => 0, 'max' => 100 ),
					'em' => array( 'min' => 0, 'max' => 6 ),
					'rem' => array( 'min' => 0, 'max' => 6 ),
				),
				'default'   => array(
					'unit' => 'px',
					'size' => 24,
				),
				'selectors' => array(
					'{{WRAPPER}} .wpg-product-grid' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'card_layout',
			array(
				'label'   => __( 'Card Display Style', 'website-product-grid' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'horizontal',
				'options' => array(
					'horizontal'         => array(
						'title' => __( 'Horizontal — image left, content right', 'website-product-grid' ),
						'icon'  => 'eicon-h-align-left',
					),
					'horizontal-reversed' => array(
						'title' => __( 'Horizontal reversed — content left, image right', 'website-product-grid' ),
						'icon'  => 'eicon-h-align-right',
					),
					'alternating'        => array(
						'title' => __( 'Alternating — first image left, next content left, and so on', 'website-product-grid' ),
						'icon'  => 'eicon-exchange',
					),
					'vertical'           => array(
						'title' => __( 'Vertical — image on top, content below', 'website-product-grid' ),
						'icon'  => 'eicon-v-align-top',
					),
				),
				'toggle'     => false,
				'description' => __( 'Horizontal (image left), Horizontal reversed (content left) and Alternating match the design mockup. Alternating swaps the two horizontal styles card-by-card (1st image-left, 2nd content-left, 3rd image-left…), exactly like the mockup — best used with 1–2 columns. Switch to Vertical for 3–4 column grids.', 'website-product-grid' ),
			)
		);

		$this->add_responsive_control(
			'card_min_height',
			array(
				'label'      => __( 'Card Minimum Height', 'website-product-grid' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'vh' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 1000 ),
					'vh' => array( 'min' => 0, 'max' => 100 ),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 0,
				),
				'description' => __( 'Set a fixed/minimum card height. In horizontal cards the image fills this height, so this is the easiest way to control the image size.', 'website-product-grid' ),
				'selectors'  => array(
					'{{WRAPPER}} .wpg-product-card' => 'min-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'card_max_width',
			array(
				'label'      => __( 'Card Maximum Width', 'website-product-grid' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 1200 ),
					'%'  => array( 'min' => 0, 'max' => 100 ),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 0,
				),
				'description' => __( 'Limit how wide each card grows. Cards are centered within their grid column. Leave at 0 for full width.', 'website-product-grid' ),
				'selectors'  => array(
					'{{WRAPPER}} .wpg-product-card' => 'max-width: {{SIZE}}{{UNIT}}; margin-left: auto; margin-right: auto;',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Content toggles and labels.
	 */
	protected function register_content_controls() {
		$this->start_controls_section(
			'section_content',
			array(
				'label' => __( 'Content', 'website-product-grid' ),
			)
		);

		$this->add_control(
			'show_image',
			array(
				'label'        => __( 'Show Product Image', 'website-product-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'website-product-grid' ),
				'label_off'    => __( 'Hide', 'website-product-grid' ),
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'image_size',
			array(
				'label'     => __( 'Image Size', 'website-product-grid' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'large',
				'options'   => $this->get_image_size_options(),
				'condition' => array( 'show_image' => 'yes' ),
			)
		);

		$this->add_control(
			'image_ratio',
			array(
				'label'     => __( 'Image Aspect Ratio', 'website-product-grid' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '4:3',
				'options'   => array(
					'16:9'   => '16:9',
					'4:3'    => '4:3',
					'3:2'    => '3:2',
					'1:1'    => '1:1',
					'3:4'    => '3:4',
					'2:3'    => '2:3',
					'6:3'    => '6:3',
					'auto'   => __( 'Original (no crop)', 'website-product-grid' ),
					'custom' => __( 'Custom ratio…', 'website-product-grid' ),
				),
				'description' => __( 'Crops the product image to this ratio. Applies to vertical cards and mobile stacking; horizontal cards fill the image column automatically.', 'website-product-grid' ),
				'condition' => array( 'show_image' => 'yes' ),
			)
		);

		$this->add_control(
			'image_ratio_custom_width',
			array(
				'label'       => __( 'Custom Ratio — Width', 'website-product-grid' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 16,
				'min'         => 1,
				'max'         => 100,
				'step'        => 1,
				'condition'   => array( 'show_image' => 'yes', 'image_ratio' => 'custom' ),
			)
		);

		$this->add_control(
			'image_ratio_custom_height',
			array(
				'label'       => __( 'Custom Ratio — Height', 'website-product-grid' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 9,
				'min'         => 1,
				'max'         => 100,
				'step'        => 1,
				'condition'   => array( 'show_image' => 'yes', 'image_ratio' => 'custom' ),
			)
		);

		$this->add_control(
			'show_title',
			array(
				'label'        => __( 'Show Title', 'website-product-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'website-product-grid' ),
				'label_off'    => __( 'Hide', 'website-product-grid' ),
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'title_tag',
			array(
				'label'     => __( 'Title HTML Tag', 'website-product-grid' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'h3',
				'options'   => array(
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
				),
				'condition' => array( 'show_title' => 'yes' ),
			)
		);

		$this->add_control(
			'show_description',
			array(
				'label'        => __( 'Show Short Description', 'website-product-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'website-product-grid' ),
				'label_off'    => __( 'Hide', 'website-product-grid' ),
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'excerpt_length',
			array(
				'label'       => __( 'Description Word Limit', 'website-product-grid' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 0,
				'min'         => 0,
				'max'         => 300,
				'description' => __( 'Maximum number of words. Set to 0 to show the full short description.', 'website-product-grid' ),
				'condition'   => array( 'show_description' => 'yes' ),
			)
		);

		$this->add_control(
			'show_highlights',
			array(
				'label'        => __( 'Show Highlights', 'website-product-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'website-product-grid' ),
				'label_off'    => __( 'Hide', 'website-product-grid' ),
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'show_read_more',
			array(
				'label'        => __( 'Show Read More Link', 'website-product-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'website-product-grid' ),
				'label_off'    => __( 'Hide', 'website-product-grid' ),
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'read_more_text',
			array(
				'label'     => __( 'Read More Text', 'website-product-grid' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( 'Read More', 'website-product-grid' ),
				'condition' => array( 'show_read_more' => 'yes' ),
			)
		);

		$this->add_control(
			'show_read_more_arrow',
			array(
				'label'        => __( 'Show Arrow', 'website-product-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'website-product-grid' ),
				'label_off'    => __( 'Hide', 'website-product-grid' ),
				'default'      => 'yes',
				'return_value' => 'yes',
				'condition'    => array( 'show_read_more' => 'yes' ),
			)
		);

		$this->add_control(
			'content_align',
			array(
				'label'   => __( 'Text Alignment (Horizontal)', 'website-product-grid' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'left',
				'options' => array(
					'left'   => array(
						'title' => __( 'Left', 'website-product-grid' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => __( 'Center', 'website-product-grid' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => __( 'Right', 'website-product-grid' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'toggle'  => false,
			)
		);

		$this->add_control(
			'content_vertical_align',
			array(
				'label'   => __( 'Text Alignment (Vertical)', 'website-product-grid' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'top',
				'options' => array(
					'top'    => array(
						'title' => __( 'Top', 'website-product-grid' ),
						'icon'  => 'eicon-v-align-top',
					),
					'middle' => array(
						'title' => __( 'Middle', 'website-product-grid' ),
						'icon'  => 'eicon-v-align-middle',
					),
					'bottom' => array(
						'title' => __( 'Bottom', 'website-product-grid' ),
						'icon'  => 'eicon-v-align-bottom',
					),
				),
				'toggle'  => false,
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Optional section heading (matches the design mockup header).
	 */
	protected function register_heading_controls() {
		$this->start_controls_section(
			'section_heading',
			array(
				'label' => __( 'Section Heading', 'website-product-grid' ),
			)
		);

		$this->add_control(
			'show_section_heading',
			array(
				'label'        => __( 'Show Section Heading', 'website-product-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'website-product-grid' ),
				'label_off'    => __( 'Hide', 'website-product-grid' ),
				'default'      => '',
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'heading_title',
			array(
				'label'     => __( 'Heading Title', 'website-product-grid' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( 'Products', 'website-product-grid' ),
				'condition' => array( 'show_section_heading' => 'yes' ),
			)
		);

		$this->add_control(
			'heading_subtitle',
			array(
				'label'       => __( 'Heading Subtitle', 'website-product-grid' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => '',
				'rows'        => 2,
				'condition'   => array( 'show_section_heading' => 'yes' ),
			)
		);

		$this->add_control(
			'view_all_text',
			array(
				'label'     => __( 'View All Link Text', 'website-product-grid' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( 'View All', 'website-product-grid' ),
				'condition' => array( 'show_section_heading' => 'yes' ),
			)
		);

		$this->add_control(
			'view_all_link',
			array(
				'label'     => __( 'View All Link', 'website-product-grid' ),
				'type'      => Controls_Manager::URL,
				'placeholder' => 'https://your-site.com/shop/',
				'condition' => array( 'show_section_heading' => 'yes' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Per-product highlight overrides (edited inside the widget).
	 */
	protected function register_highlights_controls() {
		$this->start_controls_section(
			'section_highlights',
			array(
				'label' => __( 'Highlights', 'website-product-grid' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'product_id',
			array(
				'label'       => __( 'Product ID', 'website-product-grid' ),
				'type'        => Controls_Manager::NUMBER,
				'label_block' => true,
				'placeholder' => __( 'e.g. 123', 'website-product-grid' ),
			)
		);

		$repeater->add_control(
			'highlights',
			array(
				'label'       => __( 'Highlights', 'website-product-grid' ),
				'type'        => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'rows'        => 6,
				'placeholder' => __( 'One highlight per line', 'website-product-grid' ),
				'description' => __( 'Enter one highlight per line. Each line becomes a dot-point.', 'website-product-grid' ),
			)
		);

		$this->add_control(
			'highlights_override',
			array(
				'label'       => __( 'Per-Product Highlights', 'website-product-grid' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => 'Product ID #{{{ product_id }}}',
				'default'     => array(),
				'description' => __( 'Optionally enter custom highlight bullets for specific products (one per line). Products not listed here use the highlights saved on the product edit screen.', 'website-product-grid' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Style controls.
	 */
	protected function register_style_controls() {
		$this->start_controls_section(
			'section_style_colors',
			array(
				'label' => __( 'Colors', 'website-product-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'accent_color',
			array(
				'label'     => __( 'Accent Color (links)', 'website-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#099DB3',
				'selectors' => array(
					'{{WRAPPER}} .wpg-product-grid' => '--wpg-accent: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'accent_color_hover',
			array(
				'label'     => __( 'Accent Color (links hover)', 'website-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#077E90',
				'selectors' => array(
					'{{WRAPPER}} .wpg-product-grid' => '--wpg-accent-dark: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'dot_color',
			array(
				'label'     => __( 'Highlight Dot Color', 'website-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#5FBFCE',
				'selectors' => array(
					'{{WRAPPER}} .wpg-product-grid' => '--wpg-dot: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'title_color',
			array(
				'label'     => __( 'Title Color', 'website-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#0A0A0A',
				'selectors' => array(
					'{{WRAPPER}} .wpg-card-title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'description_color',
			array(
				'label'     => __( 'Description Color', 'website-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9B9B9B',
				'selectors' => array(
					'{{WRAPPER}} .wpg-card-excerpt' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'highlight_text_color',
			array(
				'label'     => __( 'Highlight Text Color', 'website-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1C1C1C',
				'selectors' => array(
					'{{WRAPPER}} .wpg-card-highlights li' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'card_background',
			array(
				'label'     => __( 'Card Background', 'website-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .wpg-product-card' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'card_border_color',
			array(
				'label'     => __( 'Card Border Color', 'website-product-grid' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#E6E8EB',
				'selectors' => array(
					'{{WRAPPER}} .wpg-product-card' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_card',
			array(
				'label' => __( 'Card', 'website-product-grid' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'card_border_radius',
			array(
				'label'      => __( 'Border Radius', 'website-product-grid' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'default'    => array(
					'top'      => 14,
					'right'    => 14,
					'bottom'   => 14,
					'left'     => 14,
					'unit'     => 'px',
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .wpg-product-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'card_shadow',
			array(
				'label'        => __( 'Card Shadow', 'website-product-grid' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'On', 'website-product-grid' ),
				'label_off'    => __( 'Off', 'website-product-grid' ),
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$products  = $this->get_products( $settings );
		$overrides = $this->get_highlight_overrides( $settings );
		$is_edit   = \Elementor\Plugin::$instance->editor->is_edit_mode();

		$this->render_heading( $settings );

		$wrapper_class = 'wpg-product-grid';
		if ( in_array( $settings['card_layout'], array( 'horizontal', 'horizontal-reversed', 'alternating' ), true ) ) {
			$wrapper_class .= ' wpg-layout-horizontal';
		}

		$halign = isset( $settings['content_align'] ) ? $settings['content_align'] : 'left';
		$valign = isset( $settings['content_vertical_align'] ) ? $settings['content_vertical_align'] : 'top';
		$wrapper_class .= ' wpg-halign-' . sanitize_html_class( $halign );
		$wrapper_class .= ' wpg-valign-' . sanitize_html_class( $valign );

		if ( 'yes' !== $settings['card_shadow'] ) {
			$wrapper_class .= ' wpg-no-shadow';
		}

		echo '<div class="' . esc_attr( $wrapper_class ) . '" style="' . esc_attr( $this->get_grid_style_vars( $settings ) ) . '">';

		if ( empty( $products ) ) {
			if ( $is_edit ) {
				echo '<p class="wpg-empty">' . esc_html__( 'No products found. Check the widget source settings.', 'website-product-grid' ) . '</p>';
			}
			echo '</div>';
			return;
		}

		$index = 0;
		foreach ( $products as $product ) {
			$card_layout = $settings['card_layout'];
			if ( 'alternating' === $card_layout ) {
				// Alternate: 1st image-left, 2nd content-left, 3rd image-left, …
				$card_layout = ( 0 === $index % 2 ) ? 'horizontal' : 'horizontal-reversed';
			}
			$this->render_card( $product, $settings, $overrides, $card_layout );
			$index++;
		}

		echo '</div>';
	}

	/**
	 * Query the products based on the widget settings.
	 *
	 * @param array $settings Widget settings.
	 * @return \WC_Product[]|array
	 */
	protected function get_products( $settings ) {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return array();
		}

		$source = isset( $settings['source'] ) ? $settings['source'] : 'category';
		$args   = array(
			'status'     => 'publish',
			'visibility' => 'visible',
		);

		// Manual selection: order is preserved by re-sorting after the query.
		if ( 'ids' === $source ) {
			$ids = $this->parse_product_ids( isset( $settings['product_ids'] ) ? $settings['product_ids'] : '' );
			if ( empty( $ids ) ) {
				return array();
			}
			$args['include'] = $ids;
			$args['limit']   = count( $ids );

			$products = wc_get_products( $args );
			return $this->sort_products_by_ids( $products, $ids );
		}

		$args['limit']   = max( 1, absint( isset( $settings['products_count'] ) ? $settings['products_count'] : 4 ) );
		$args['orderby'] = isset( $settings['orderby'] ) ? $settings['orderby'] : 'date';
		$args['order']   = 'asc' === strtolower( (string) $settings['order'] ) ? 'ASC' : 'DESC';

		if ( 'category' === $source ) {
			// SELECT2 multiple may come back as an array or a comma-separated string.
			$category_setting = isset( $settings['product_categories'] ) ? $settings['product_categories'] : array();
			if ( is_string( $category_setting ) ) {
				$category_setting = explode( ',', $category_setting );
			}
			$term_ids = array_map( 'absint', (array) $category_setting );
			$term_ids = array_values( array_filter( $term_ids ) );
			if ( empty( $term_ids ) ) {
				return array();
			}
			$args['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				array(
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $term_ids,
					'operator' => 'IN',
				),
			);
		}

		return wc_get_products( $args );
	}

	/**
	 * Render the optional section heading.
	 *
	 * @param array $settings Widget settings.
	 */
	protected function render_heading( $settings ) {
		if ( 'yes' !== $settings['show_section_heading'] ) {
			return;
		}

		$title         = isset( $settings['heading_title'] ) ? $settings['heading_title'] : '';
		$subtitle      = isset( $settings['heading_subtitle'] ) ? $settings['heading_subtitle'] : '';
		$view_all_text = isset( $settings['view_all_text'] ) ? $settings['view_all_text'] : '';
		$view_all_url  = isset( $settings['view_all_link'] ) ? $settings['view_all_link'] : array();

		echo '<div class="wpg-grid-heading">';
		echo '<div class="wpg-grid-heading-copy">';
		if ( '' !== (string) $title ) {
			echo '<h2 class="wpg-grid-heading-title">' . esc_html( $title ) . '</h2>';
		}
		if ( '' !== (string) $subtitle ) {
			echo '<p class="wpg-grid-heading-subtitle">' . esc_html( $subtitle ) . '</p>';
		}
		echo '</div>';

		if ( '' !== (string) $view_all_text && ! empty( $view_all_url['url'] ) ) {
			$target = ! empty( $view_all_url['is_external'] ) ? '_blank' : '';
			$rel    = array();
			if ( ! empty( $view_all_url['nofollow'] ) ) {
				$rel[] = 'nofollow';
			}
			if ( '_blank' === $target ) {
				$rel[] = 'noopener';
			}
			$target_attr = $target ? ' target="' . esc_attr( $target ) . '"' : '';
			$rel_attr    = $rel ? ' rel="' . esc_attr( implode( ' ', $rel ) ) . '"' : '';

			echo '<a class="wpg-grid-heading-link" href="' . esc_url( $view_all_url['url'] ) . '"' . $target_attr . $rel_attr . '>'
				. esc_html( $view_all_text )
				. '<span class="wpg-more-arrow" aria-hidden="true">→</span></a>';
		}

		echo '</div>';
	}

	/**
	 * Render a single product card.
	 *
	 * The horizontal-reversed style (content left, image right) is implemented by
	 * swapping the DOM output order here, so it does not depend on any CSS flip.
	 * For the alternating style, the caller passes the per-card effective layout.
	 *
	 * @param \WC_Product $product      Product object.
	 * @param array       $settings     Widget settings.
	 * @param array       $overrides    Highlight overrides keyed by product ID.
	 * @param string|null $card_layout  Effective layout for this card; null uses the widget setting.
	 */
	protected function render_card( $product, $settings, $overrides, $card_layout = null ) {
		$media_html = $this->get_card_media_html( $product, $settings );
		$body_html  = $this->get_card_body_html( $product, $settings, $overrides );

		if ( null === $card_layout ) {
			$card_layout = isset( $settings['card_layout'] ) ? $settings['card_layout'] : 'horizontal';
		}

		echo '<article class="wpg-product-card">';

		if ( 'horizontal-reversed' === $card_layout ) {
			// Content first (left), image second (right).
			echo $body_html;
			echo $media_html;
		} else {
			// Image first (left/top), content second (right/bottom).
			echo $media_html;
			echo $body_html;
		}

		echo '</article>';
	}

	/**
	 * Build the card media (image) markup.
	 *
	 * @param \WC_Product $product  Product object.
	 * @param array       $settings Widget settings.
	 * @return string
	 */
	protected function get_card_media_html( $product, $settings ) {
		if ( 'yes' !== $settings['show_image'] ) {
			return '';
		}

		$permalink = $product->get_permalink();
		$title     = $product->get_name();

		$html = '<div class="wpg-card-media">';
		if ( $permalink ) {
			$html .= '<a href="' . esc_url( $permalink ) . '" aria-label="' . esc_attr( $title ) . '">';
		}
		$html .= $product->get_image( $this->get_image_size( $settings ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WC escapes image markup.
		if ( $permalink ) {
			$html .= '</a>';
		}
		$html .= '</div>';

		return $html;
	}

	/**
	 * Build the card body (title, excerpt, highlights, read more) markup.
	 *
	 * @param \WC_Product $product   Product object.
	 * @param array       $settings  Widget settings.
	 * @param array       $overrides Highlight overrides keyed by product ID.
	 * @return string
	 */
	protected function get_card_body_html( $product, $settings, $overrides ) {
		$id        = $product->get_id();
		$permalink = $product->get_permalink();
		$title     = $product->get_name();

		$html = '<div class="wpg-card-body">';

		if ( 'yes' === $settings['show_title'] ) {
			$tag = $this->get_title_tag( $settings );
			$html .= '<' . esc_attr( $tag ) . ' class="wpg-card-title">';
			if ( $permalink ) {
				$html .= '<a href="' . esc_url( $permalink ) . '">' . esc_html( $title ) . '</a>';
			} else {
				$html .= esc_html( $title );
			}
			$html .= '</' . esc_attr( $tag ) . '>';
		}

		if ( 'yes' === $settings['show_description'] ) {
			$excerpt = $product->get_short_description();
			if ( '' !== (string) $excerpt ) {
				$excerpt = $this->trim_excerpt( $excerpt, $settings );
				$html .= '<p class="wpg-card-excerpt">' . esc_html( $excerpt ) . '</p>';
			}
		}

		if ( 'yes' === $settings['show_highlights'] ) {
			$highlights = isset( $overrides[ $id ] ) ? $overrides[ $id ] : WPG_Product_Meta::get_highlights( $id );
			if ( ! empty( $highlights ) ) {
				$html .= '<ul class="wpg-card-highlights">';
				foreach ( $highlights as $highlight ) {
					$html .= '<li>' . esc_html( $highlight ) . '</li>';
				}
				$html .= '</ul>';
			}
		}

		if ( 'yes' === $settings['show_read_more'] && $permalink ) {
			$arrow = '';
			if ( 'yes' === $settings['show_read_more_arrow'] ) {
				$arrow = ' <span class="wpg-more-arrow" aria-hidden="true">→</span>';
			}
			$html .= '<a class="wpg-card-more" href="' . esc_url( $permalink ) . '">'
				. esc_html( $settings['read_more_text'] )
				. $arrow
				. '</a>';
		}

		$html .= '</div>';

		return $html;
	}

	/**
	 * Build the CSS custom-property block used to control responsive columns.
	 *
	 * @param array $settings Widget settings.
	 * @return string Inline style declaration value (no wrapping style="...").
	 */
	protected function get_grid_style_vars( $settings ) {
		$cols   = absint( isset( $settings['columns'] ) ? $settings['columns'] : 4 );
		$tablet = absint( isset( $settings['columns_tablet'] ) ? $settings['columns_tablet'] : 2 );
		$mobile = absint( isset( $settings['columns_mobile'] ) ? $settings['columns_mobile'] : 1 );

		return sprintf(
			'--wpg-cols:%1$d;--wpg-cols-tablet:%2$d;--wpg-cols-mobile:%3$d;--wpg-ratio:%4$s;',
			max( 1, min( 4, $cols ) ),
			max( 1, min( 4, $tablet ) ),
			max( 1, min( 2, $mobile ) ),
			$this->get_image_ratio( $settings )
		);
	}

	/**
	 * Resolve the image aspect ratio into a CSS value ("16 / 9", "auto", or "W / H").
	 *
	 * @param array $settings Widget settings.
	 * @return string
	 */
	protected function get_image_ratio( $settings ) {
		$ratio = isset( $settings['image_ratio'] ) ? $settings['image_ratio'] : '4:3';

		if ( 'auto' === $ratio ) {
			return 'auto';
		}

		if ( 'custom' === $ratio ) {
			$width  = max( 1, absint( isset( $settings['image_ratio_custom_width'] ) ? $settings['image_ratio_custom_width'] : 16 ) );
			$height = max( 1, absint( isset( $settings['image_ratio_custom_height'] ) ? $settings['image_ratio_custom_height'] : 9 ) );
			return $width . ' / ' . $height;
		}

		// Presets are stored like "16:9" → convert to CSS "16 / 9".
		if ( preg_match( '/^(\d+)\s*:\s*(\d+)$/', (string) $ratio, $m ) ) {
			return $m[1] . ' / ' . $m[2];
		}

		return '4 / 3';
	}

	/**
	 * Parse a comma-separated list of product IDs.
	 *
	 * @param mixed $raw Raw setting value (string or array).
	 * @return int[]
	 */
	protected function parse_product_ids( $raw ) {
		if ( is_array( $raw ) ) {
			$raw = implode( ',', $raw );
		}
		$ids = array();
		foreach ( explode( ',', (string) $raw ) as $part ) {
			$id = absint( trim( $part ) );
			if ( $id > 0 ) {
				$ids[] = $id;
			}
		}
		return array_values( array_unique( $ids ) );
	}

	/**
	 * Re-order products to match the manually-entered ID order.
	 *
	 * @param \WC_Product[] $products Queried products.
	 * @param int[]         $ids      Desired order of IDs.
	 * @return \WC_Product[]
	 */
	protected function sort_products_by_ids( $products, $ids ) {
		$by_id = array();
		foreach ( $products as $product ) {
			$by_id[ $product->get_id() ] = $product;
		}
		$ordered = array();
		foreach ( $ids as $id ) {
			if ( isset( $by_id[ $id ] ) ) {
				$ordered[] = $by_id[ $id ];
			}
		}
		return $ordered;
	}

	/**
	 * Parse the highlight overrides repeater into a product-ID => lines map.
	 *
	 * @param array $settings Widget settings.
	 * @return array
	 */
	protected function get_highlight_overrides( $settings ) {
		$overrides = array();
		$items     = isset( $settings['highlights_override'] ) ? (array) $settings['highlights_override'] : array();

		foreach ( $items as $item ) {
			$id = absint( isset( $item['product_id'] ) ? $item['product_id'] : 0 );
			if ( $id <= 0 ) {
				continue;
			}
			$raw   = isset( $item['highlights'] ) ? (string) $item['highlights'] : '';
			$lines = preg_split( '/\r\n|\r|\n/', $raw );
			$lines = array_values( array_filter( array_map( 'trim', (array) $lines ), 'strlen' ) );

			// An empty override must not suppress the product's saved highlights.
			if ( empty( $lines ) ) {
				continue;
			}

			$overrides[ $id ] = $lines;
		}

		return $overrides;
	}

	/**
	 * Trim the excerpt to a word limit (0 = no limit).
	 *
	 * @param string $text     Excerpt text.
	 * @param array  $settings Widget settings.
	 * @return string
	 */
	protected function trim_excerpt( $text, $settings ) {
		// Preserve word boundaries across tag boundaries before stripping HTML,
		// so "Line one<br>Line two" does not become "Line oneLine two".
		$text = preg_replace( '#<\s*br[^>]*>#i', ' ', $text );
		$text = preg_replace( '#</(p|div|li|h[1-6]|ul|ol|section|blockquote|tr)>#i', ' ', $text );

		$text = wp_strip_all_tags( $text, true );

		// Decode entities (&nbsp; etc.) and normalize all whitespace (incl. NBSP) to single spaces.
		$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$text = str_replace( "\xC2\xA0", ' ', $text );
		$text = preg_replace( '/\s+/', ' ', $text );
		$text = trim( $text );

		$limit = absint( isset( $settings['excerpt_length'] ) ? $settings['excerpt_length'] : 0 );
		if ( $limit > 0 ) {
			$words = preg_split( '/\s+/', $text );
			if ( count( $words ) > $limit ) {
				$words = array_slice( $words, 0, $limit );
				$text  = implode( ' ', $words ) . '…';
			}
		}

		return $text;
	}

	/**
	 * Resolve the title HTML tag.
	 *
	 * @param array $settings Widget settings.
	 * @return string
	 */
	protected function get_title_tag( $settings ) {
		$tag = isset( $settings['title_tag'] ) ? $settings['title_tag'] : 'h3';
		return in_array( $tag, array( 'h2', 'h3', 'h4' ), true ) ? $tag : 'h3';
	}

	/**
	 * Resolve the image size.
	 *
	 * @param array $settings Widget settings.
	 * @return string
	 */
	protected function get_image_size( $settings ) {
		$size  = isset( $settings['image_size'] ) ? $settings['image_size'] : 'large';
		$known = array_keys( $this->get_image_size_options() );
		return in_array( $size, $known, true ) ? $size : 'large';
	}

	/**
	 * Image size options.
	 *
	 * @return array
	 */
	protected function get_image_size_options() {
		$sizes = get_intermediate_image_sizes();
		$options = array();
		foreach ( $sizes as $size ) {
			$options[ $size ] = $size;
		}
		if ( ! isset( $options['full'] ) ) {
			$options['full'] = 'full';
		}
		return $options;
	}

	/**
	 * Product category options for the SELECT2 control.
	 *
	 * @return array
	 */
	protected function get_product_category_options() {
		$options = get_transient( WPG_CATEGORY_OPTIONS_KEY );

		if ( is_array( $options ) ) {
			return $options;
		}

		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return array();
		}

		$options = array();
		foreach ( $terms as $term ) {
			$options[ $term->term_id ] = $term->name;
		}

		set_transient( WPG_CATEGORY_OPTIONS_KEY, $options, DAY_IN_SECONDS );

		return $options;
	}
}
