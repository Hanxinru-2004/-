/*
 * Elementor Product Grid — frontend enhancements.
 *
 * 1. Keeps the "Add to Bag" button static after a successful AJAX add, and
 *    removes the "View cart" link WooCommerce inserts.
 * 2. Keeps the wishlist button icon-only, so WPC Smart Wishlist can never
 *    print "Add to wishlist" / "Browse wishlist" inside it.
 */
(function ($) {
	'use strict';

	/* ---------------- Add to Bag ---------------- */

	$(document.body).on('added_to_cart', function (event, fragments, cartHash, button) {
		var $btn = $(button);
		if (!$btn.hasClass('epg-add-to-bag')) {
			return;
		}

		// Remove the "View cart" link WooCommerce inserts after a successful add.
		$btn.closest('.epg-actions').find('.added_to_cart.wc-forward').remove();

		// Keep the button in its original "Add to Bag" state.
		$btn.removeClass('added loading');
	});

	/* ---------------- Wishlist: icon only, never text ----------------
	 *
	 * WPC Smart Wishlist's woosw_refresh_buttons() runs on every page load and
	 * executes `$('.woosw-btn:not(.woosw-btn-has-icon)').text( ... )`. jQuery
	 * .text() replaces every child node, so it deleted our two heart spans and
	 * left a bare "Add to wishlist" / "Browse wishlist" text node behind.
	 *
	 * The primary fix is the `woosw-btn-has-icon` class in the button markup,
	 * which makes woosw skip this button. This observer is the backstop: if any
	 * plugin or theme ever writes into the button again, the text is removed and
	 * the hearts are put back.
	 */

	var HARDENED = 'epgWishlistHardened';

	/**
	 * Remove foreign nodes from a wishlist button and restore its heart spans.
	 *
	 * Loop-safe: the observer is disconnected before we mutate and reconnected
	 * afterwards, so our own changes are never re-observed.
	 */
	function sanitize(btn, observer, icons) {
		if (observer) {
			observer.disconnect();
		}

		// Drop text nodes ("Add to wishlist") and any element that is not ours
		// (woosw's text span / tick / spinner, a theme label, ...).
		for (var i = btn.childNodes.length - 1; i >= 0; i--) {
			var node = btn.childNodes[i];
			var isOurs = node.nodeType === 1 &&
				node.className &&
				String(node.className).indexOf('epg-wishlist-icon') !== -1;

			if (!isOurs) {
				btn.removeChild(node);
			}
		}

		// Put the hearts back if they were wiped.
		if (icons.off && !icons.off.parentNode) {
			btn.appendChild(icons.off);
		}
		if (icons.on && !icons.on.parentNode) {
			btn.appendChild(icons.on);
		}

		// Kill native and hint.css tooltips too — the icon should stand alone.
		btn.removeAttribute('title');
		btn.removeAttribute('data-hint');

		if (observer) {
			observer.observe(btn, { childList: true, characterData: true, subtree: true });
		}
	}

	/**
	 * Attach the guard to every wishlist button inside `root` that lacks one.
	 *
	 * @param {jQuery|Element|Document} root Optional scope. Defaults to document.
	 */
	function hardenWishlistButtons(root) {
		$(root || document).find('.epg-wishlist-btn').addBack('.epg-wishlist-btn').each(function () {
			var btn = this;
			var $btn = $(btn);

			if ($btn.data(HARDENED)) {
				return;
			}
			$btn.data(HARDENED, true);

			// Cache the heart nodes so they can be re-attached if they get wiped.
			var icons = {
				off: btn.querySelector('.epg-wishlist-icon--off'),
				on: btn.querySelector('.epg-wishlist-icon--on')
			};

			var observer = null;
			if (window.MutationObserver) {
				observer = new MutationObserver(function () {
					sanitize(btn, observer, icons);
				});
			}

			// First pass also starts the observer.
			sanitize(btn, observer, icons);
		});
	}

	/**
	 * Mirror woosw's added/removed state onto the button.
	 *
	 * woosw already sets `woosw-added` itself; this only guarantees the filled
	 * heart stays correct if that ever stops happening for icon-only buttons.
	 *
	 * @param {number|string} productId Product ID woosw reported.
	 * @param {boolean}       added     Whether it is now in the wishlist.
	 */
	function syncState(productId, added) {
		$('.epg-wishlist-btn[data-id="' + productId + '"]').toggleClass('woosw-added', !!added);
	}

	$(function () {
		hardenWishlistButtons(document);
	});

	// woosw repaints buttons over AJAX after page load — re-check each time.
	$(document.body).on('woosw_buttons_refreshed woosw_refresh_button_id woosw_data_refreshed', function () {
		hardenWishlistButtons(document);
	});

	$(document.body).on('woosw_add', function (event, productId) {
		syncState(productId, true);
	});

	$(document.body).on('woosw_remove', function (event, productId) {
		syncState(productId, false);
	});

	// Elementor re-renders the widget in the editor and on AJAX-loaded pages;
	// those fresh buttons need their own guard.
	function registerElementorHook() {
		if (!window.elementorFrontend || !elementorFrontend.hooks) {
			return false;
		}

		elementorFrontend.hooks.addAction(
			'frontend/element_ready/epg-product-grid.default',
			function ($scope) {
				hardenWishlistButtons($scope);
			}
		);

		return true;
	}

	if (!registerElementorHook()) {
		$(window).on('elementor/frontend/init', registerElementorHook);
	}
})(jQuery);
