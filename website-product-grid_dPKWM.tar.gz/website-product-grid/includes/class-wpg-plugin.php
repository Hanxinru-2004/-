<?php
/**
 * Plugin bootstrap: dependency checks, asset registration, widget registration.
 *
 * @package WebsiteProductGrid
 */

defined( 'ABSPATH' ) || exit;

/**
 * Main plugin class.
 */
class WPG_Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var WPG_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Get the singleton instance.
	 *
	 * @return WPG_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor. Hooks into plugins_loaded.
	 */
	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	/**
	 * Initialize the plugin once all plugins are loaded.
	 */
	public function init() {
		load_plugin_textdomain( 'website-product-grid', false, dirname( WPG_BASENAME ) . '/languages' );

		// Bail early (but stay silent) if the required plugins are missing.
		if ( ! $this->dependencies_met() ) {
			add_action( 'admin_notices', array( $this, 'dependencies_notice' ) );
			return;
		}

		require_once WPG_PATH . 'includes/class-wpg-product-meta.php';
		WPG_Product_Meta::init();

		// Register the widget against both the modern and legacy Elementor hooks.
		if ( defined( 'ELEMENTOR_VERSION' ) && version_compare( ELEMENTOR_VERSION, '3.5.0', '>=' ) ) {
			add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
		} else {
			add_action( 'elementor/widgets/widgets_registered', array( $this, 'register_widgets_legacy' ) );
		}

		add_action( 'elementor/elements/categories_registered', array( $this, 'register_category' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_styles' ) );

		// Keep the cached category options fresh when product categories change.
		add_action( 'created_product_cat', array( $this, 'flush_category_options_cache' ) );
		add_action( 'edited_product_cat', array( $this, 'flush_category_options_cache' ) );
		add_action( 'delete_product_cat', array( $this, 'flush_category_options_cache' ) );
	}

	/**
	 * Whether Elementor and WooCommerce are both active.
	 *
	 * @return bool
	 */
	private function dependencies_met() {
		return class_exists( '\Elementor\Plugin' ) && class_exists( 'WooCommerce' );
	}

	/**
	 * Admin notice shown when Elementor or WooCommerce is missing.
	 */
	public function dependencies_notice() {
		$message = sprintf(
			/* translators: %1$s plugin name, %2$s and %3$s required plugins */
			esc_html__( '%1$s requires %2$s and %3$s to be installed and active.', 'website-product-grid' ),
			'<strong>Website Product Grid</strong>',
			'<a href="https://wordpress.org/plugins/elementor/">Elementor</a>',
			'<a href="https://wordpress.org/plugins/woocommerce/">WooCommerce</a>'
		);
		echo '<div class="notice notice-warning"><p>' . $message . '</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- message is built with escaped parts.
	}

	/**
	 * Register the widget (Elementor 3.5+).
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Widgets manager instance.
	 */
	public function register_widgets( $widgets_manager ) {
		require_once WPG_PATH . 'includes/class-wpg-product-grid-widget.php';
		$widgets_manager->register( new WPG_Product_Grid_Widget() );
	}

	/**
	 * Register the widget (Elementor < 3.5).
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Widgets manager instance.
	 */
	public function register_widgets_legacy( $widgets_manager ) {
		require_once WPG_PATH . 'includes/class-wpg-product-grid-widget.php';
		$widgets_manager->register_widget_type( new WPG_Product_Grid_Widget() );
	}

	/**
	 * Register a widget category so the widget is easy to find.
	 *
	 * @param \Elementor\Elements_Manager $elements_manager Elements manager instance.
	 */
	public function register_category( $elements_manager ) {
		$elements_manager->add_category(
			'website-product-grid',
			array(
				'title' => __( 'Website Product Grid', 'website-product-grid' ),
				'icon'  => 'eicon-gallery-grid',
			)
		);
	}

	/**
	 * Register the frontend stylesheet (enqueued by the widget on demand).
	 */
	public function register_styles() {
		wp_register_style(
			'wpg-product-grid',
			WPG_URL . 'assets/css/product-grid.css',
			array(),
			WPG_VERSION
		);
	}

	/**
	 * Flush the cached product category options (used by the widget's SELECT2).
	 */
	public function flush_category_options_cache() {
		if ( defined( 'WPG_CATEGORY_OPTIONS_KEY' ) && function_exists( 'delete_transient' ) ) {
			delete_transient( WPG_CATEGORY_OPTIONS_KEY );
		}
	}
}
