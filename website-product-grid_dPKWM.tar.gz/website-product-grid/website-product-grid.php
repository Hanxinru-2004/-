<?php
/**
 * Plugin Name:       Website Product Grid
 * Plugin URI:        https://example.com/website-product-grid
 * Description:       Display WooCommerce products in a styled, responsive grid via an Elementor widget — with per-product highlight bullets, category filtering, and manual product selection.
 * Version:           1.0.4
 * Author:            Website Product Grid
 * Author URI:        https://example.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       website-product-grid
 * Domain Path:       /languages
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Requires Plugins:  elementor, woocommerce
 *
 * @package WebsiteProductGrid
 */

defined( 'ABSPATH' ) || exit;

define( 'WPG_VERSION', '1.0.4' );
define( 'WPG_FILE', __FILE__ );
define( 'WPG_PATH', plugin_dir_path( __FILE__ ) );
define( 'WPG_URL', plugin_dir_url( __FILE__ ) );
define( 'WPG_BASENAME', plugin_basename( __FILE__ ) );
define( 'WPG_CATEGORY_OPTIONS_KEY', 'wpg_product_cat_options' );

require_once WPG_PATH . 'includes/class-wpg-plugin.php';

/**
 * Boot the plugin.
 */
function wpg_plugin() {
	return WPG_Plugin::instance();
}

wpg_plugin();
