=== Website Product Grid ===
Contributors: wpg
Tags: elementor, woocommerce, products, grid, shop, woocommerce-products
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Requires Plugins: elementor, woocommerce
Stable tag: 1.0.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Display WooCommerce products in a styled, responsive grid via an Elementor widget — with per-product highlight bullets, category filtering, and manual product selection.

== Description ==

**Website Product Grid** adds an Elementor widget that renders your WooCommerce products as polished, card-style grids.

Each product card shows:

* **Product title** — from the WooCommerce product title
* **Short description** — from the WooCommerce product short description
* **Highlight bullets** — a dot-point list (4 bullets in the design mockup). Highlights are stored as a per-product custom field (edited on the product edit screen as one bullet per line), and can be overridden per widget instance.
* **Read More link** — links to the product detail page

**Widget features:**

* Choose products by **category**, by **manual product IDs**, or show the **latest** products
* Set **1 / 2 / 3 / 4 columns** per row, with separate tablet and mobile column counts
* Show or hide the image, title, description, highlights, and Read More link independently
* Image aspect ratio presets (16:9, 4:3, 1:1, 6:3…) plus a custom ratio input; applies to vertical and horizontal cards
* Card **height** and **maximum width** controls
* Text alignment controls — horizontal (left / center / right) and vertical (top / middle / bottom)
* Optional section heading (title, subtitle, "View All" link)
* **Card display style** — horizontal (image left, content right — matches the design mockup, and the default), horizontal reversed (content left, image right), alternating (swaps the two horizontal styles card-by-card, like the mockup), or vertical (image on top)
* Accent color, highlight dot color, and card styling controls

**Per-product highlights:**

1. Edit a product in **Products → All Products**.
2. In the **Product Highlights** box, enter one highlight per line (each line becomes a dot-point).
3. In the Elementor widget, optionally override highlights per product using the **Highlights → Per-Product Highlights** repeater.

== Installation ==

1. Upload the `website-product-grid` folder to `/wp-content/plugins/`.
2. Activate the plugin through the **Plugins** screen. It requires **Elementor** and **WooCommerce** to be active.
3. Open the Elementor editor, drag the **Product Grid** widget into a section, and configure it.

== Frequently Asked Questions ==

= Where do I edit the highlight bullets? =

Either on the product edit screen (Products → All Products → the "Product Highlights" box, one line per bullet), or inside the widget using the Highlights repeater. The widget override takes precedence.

= Can I show products from a specific category? =

Yes. Set *Product Source* to **Filter by category** and pick one or more categories.

= Can I choose specific products? =

Yes. Set *Product Source* to **Choose products manually** and enter the product IDs separated by commas. The order you type them is preserved.

== Changelog ==

= 1.0.4 =
* **Card height & width control** — added responsive "Card Minimum Height" and "Card Maximum Width" settings in the Layout tab. On horizontal cards the image fills the card height, so this is the direct way to resize the image.
* **Image Aspect Ratio now applies to horizontal cards** — the image always fills the full card height and its width follows the chosen ratio (16:9, 4:3, 1:1, custom, etc.), clamped between 28%–55% of the card.
* **Text alignment** — added horizontal (left / center / right) and vertical (top / middle / bottom) alignment controls for the card content.

= 1.0.3 =
* Added an **Image Aspect Ratio** option to the Content tab: preset ratios (16:9, 4:3, 3:2, 1:1, 3:4, 2:3, 6:3, original) plus a **Custom ratio** input (width : height, fully adjustable). Applies to vertical cards and mobile stacking.

= 1.0.2 =
* Added an **Alternating** card display style: cards swap between image-left and content-left layouts card-by-card (1st image-left, 2nd content-left, 3rd image-left…), matching the alternating rows in the design mockup. Best used with 1–2 columns.

= 1.0.1 =
* Fixed the "content left, image right" horizontal-reversed card style: the image/text swap is now handled in the rendered markup (no longer dependent on a CSS rule that could be cached/stale), and the plugin version was bumped so the updated stylesheet loads fresh.

= 1.0.0 =
* Initial release.
